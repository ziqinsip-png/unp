import { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import rateLimit from 'express-rate-limit';

export interface AdminUser { id: string; email: string; role: string; }
export interface AuthenticatedRequest extends Request { adminUser?: AdminUser; }

const SECRET = process.env.AUTH_SECRET || 'unp-secret-2026';
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'admin@example.com';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';

export const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 50,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Terlalu banyak percobaan login gagal.' },
});

function sign(payload: AdminUser & { exp: number }): string {
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', SECRET).update(body).digest('base64url');
  return `${body}.${sig}`;
}

function decode(token: string): AdminUser | null {
  try {
    const [body, sig] = token.split('.');
    if (!body || !sig) return null;
    const expected = crypto.createHmac('sha256', SECRET).update(body).digest('base64url');
    if (sig.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8')) as AdminUser & { exp: number };
    if (!payload.exp || payload.exp < Date.now()) return null;
    return { id: payload.id, email: payload.email, role: payload.role };
  } catch { return null; }
}

export async function createSession(email: string, userId = 'admin-1'): Promise<string> {
  return sign({ id: userId, email, role: 'ADMIN', exp: Date.now() + 7 * 24 * 60 * 60 * 1000 });
}
export function destroySession(_token: string): void {}
export function verifySession(token: string): AdminUser | null { return token ? decode(token) : null; }

export function requireAdminAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  const token = authHeader?.startsWith('Bearer ') ? authHeader.slice(7).trim() : req.cookies?.unp_session;
  const user = token ? verifySession(token) : null;
  if (!user) { res.status(401).json({ error: 'Akses ditolak: Session kadaluarsa atau tidak valid.' }); return; }
  if (user.role !== 'ADMIN') { res.status(403).json({ error: 'Akses ditolak.' }); return; }
  req.adminUser = user;
  next();
}

export function checkCredentials(identifier: string, password: string): boolean {
  const norm = identifier.toLowerCase().trim();

  // Primary Netlify Environment Variable account.
  if (ADMIN_PASSWORD && norm === ADMIN_EMAIL.toLowerCase().trim() && password === ADMIN_PASSWORD) {
    return true;
  }

  // Compatibility with the original portal accounts. These remain accepted
  // even when ADMIN_EMAIL / ADMIN_PASSWORD are configured in Netlify.
  const legacyAccounts = [
    { username: 'mono170408', email: 'mono170408@gmail.com', password: 'ziqin17042008' },
    { username: 'admin', email: 'admin@unpkediri.ac.id', password: 'AdminUNP#2026!' },
  ];

  return legacyAccounts.some((acc) =>
    (norm === acc.username || norm === acc.email) && password === acc.password
  );
}

export function getCredentials() { return { email: ADMIN_EMAIL, password: ADMIN_PASSWORD }; }
export function logAuditAction(userId?: string, userEmail?: string, action?: string, details?: string): void {
  console.log(`[AUDIT] [${new Date().toISOString()}] ${userEmail || 'admin'} (${userId || 'system'}): ${action || ''} - ${details || ''}`);
}
