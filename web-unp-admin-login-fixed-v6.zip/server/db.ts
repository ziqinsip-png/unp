import pg from 'pg';
import fs from 'fs';
import path from 'path';

const { Pool } = pg;

const connectionString = process.env.NETLIFY_DB_URL || process.env.DATABASE_URL;
if (!connectionString) {
  console.warn('[DB] NETLIFY_DB_URL/DATABASE_URL is not set yet.');
}

const pool = new Pool({
  connectionString,
  ssl: connectionString && !/localhost|127\.0\.0\.1/.test(connectionString) ? { rejectUnauthorized: false } : undefined,
  max: 5,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000,
});

let initialized = false;
let initializing: Promise<void> | null = null;

const schema = `
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  passwordHash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'ADMIN',
  createdAt TEXT NOT NULL,
  updatedAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  userId TEXT NOT NULL,
  expiresAt TEXT NOT NULL,
  createdAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS students (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  npm TEXT NOT NULL,
  position TEXT NOT NULL DEFAULT 'Anggota',
  division TEXT NOT NULL DEFAULT 'Umum',
  orderIndex INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS courses (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  code TEXT NOT NULL,
  sks INTEGER NOT NULL,
  description TEXT,
  createdAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS lecturers (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT,
  room TEXT,
  createdAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS schedules (
  id TEXT PRIMARY KEY,
  courseId TEXT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  lecturerId TEXT NOT NULL REFERENCES lecturers(id) ON DELETE CASCADE,
  dayOfWeek INTEGER NOT NULL,
  startTime TEXT NOT NULL,
  endTime TEXT NOT NULL,
  room TEXT NOT NULL,
  recurrenceType TEXT NOT NULL DEFAULT 'WEEKLY',
  specificDate TEXT,
  createdAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS announcements (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  published INTEGER NOT NULL DEFAULT 1,
  category TEXT NOT NULL DEFAULT 'Umum',
  createdAt TEXT NOT NULL,
  updatedAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY,
  userId TEXT NOT NULL,
  userEmail TEXT NOT NULL,
  action TEXT NOT NULL,
  details TEXT,
  createdAt TEXT NOT NULL
);
`;

function convertParams(sql: string, params: any[]) {
  let i = 0;
  const text = sql.replace(/\?/g, () => `$${++i}`);
  return { text, values: params };
}

const keyMap: Record<string, string> = { passwordhash: 'passwordHash', createdat: 'createdAt', updatedat: 'updatedAt', userid: 'userId', expiresat: 'expiresAt', orderindex: 'orderIndex', courseid: 'courseId', lecturerid: 'lecturerId', dayofweek: 'dayOfWeek', starttime: 'startTime', endtime: 'endTime', room: 'room', recurrencetype: 'recurrenceType', specificdate: 'specificDate', useremail: 'userEmail', coursename: 'courseName', coursecode: 'courseCode', coursesks: 'courseSks', coursedescription: 'courseDescription', lecturername: 'lecturerName', lecturerroom: 'lecturerRoom' };
function normalizeRow(row: any) { return Object.fromEntries(Object.entries(row).map(([k,v]) => [keyMap[k] || k, v])); }

async function seedFromBackup(client: pg.PoolClient) {
  const dataPath = path.join(process.cwd(), 'data', 'seed-data.json');
  if (!fs.existsSync(dataPath)) return;
  const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
  const { rows } = await client.query('SELECT COUNT(*)::int AS count FROM users');
  if (rows[0].count > 0) return;

  await client.query('BEGIN');
  try {
    const insert = async (table: string, columns: string[], rows: any[]) => {
      for (const row of rows) {
        const values = columns.map((c) => row[c]);
        const placeholders = values.map((_, i) => `$${i + 1}`).join(', ');
        await client.query(`INSERT INTO ${table} (${columns.join(', ')}) VALUES (${placeholders}) ON CONFLICT DO NOTHING`, values);
      }
    };
    await insert('users', ['id','email','passwordHash','role','createdAt','updatedAt'], data.users || []);
    await insert('students', ['id','name','npm','position','division','orderIndex'], data.students || []);
    await insert('courses', ['id','name','code','sks','description','createdAt'], data.courses || []);
    await insert('lecturers', ['id','name','email','room','createdAt'], data.lecturers || []);
    await insert('schedules', ['id','courseId','lecturerId','dayOfWeek','startTime','endTime','room','recurrenceType','specificDate','createdAt'], data.schedules || []);
    await insert('announcements', ['id','title','content','published','category','createdAt','updatedAt'], data.announcements || []);
    await insert('audit_logs', ['id','userId','userEmail','action','details','createdAt'], data.audit_logs || []);
    await client.query('COMMIT');
    console.log('[DB] Existing SQLite data copied into PostgreSQL.');
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  }
}

export async function initDb(): Promise<void> {
  if (initialized) return;
  if (initializing) return initializing;
  initializing = (async () => {
    const client = await pool.connect();
    try {
      await client.query(schema);
      await seedFromBackup(client);
      initialized = true;
      console.log('[DB] PostgreSQL ready.');
    } finally {
      client.release();
      initializing = null;
    }
  })();
  return initializing;
}

export async function query<T = any>(sql: string, params: any[] = []): Promise<T[]> {
  await initDb();
  const result = await pool.query(convertParams(sql, params));
  return result.rows.map(normalizeRow) as T[];
}

export async function queryOne<T = any>(sql: string, params: any[] = []): Promise<T | null> {
  const rows = await query<T>(sql, params);
  return rows.length ? rows[0] : null;
}

export async function run(sql: string, params: any[] = []): Promise<void> {
  await initDb();
  await pool.query(convertParams(sql, params));
}

export async function closeDb() {
  await pool.end();
}
