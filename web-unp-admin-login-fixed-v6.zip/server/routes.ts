import { Router, Request, Response } from 'express';
import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { z } from 'zod';
import { query, queryOne, run } from './db.ts';
import {
  AuthenticatedRequest,
  createSession,
  destroySession,
  loginLimiter,
  logAuditAction,
  requireAdminAuth,
  verifySession,
  checkCredentials,
} from './auth.ts';

export const apiRouter = Router();

// ==========================================
// INDONESIAN TIME HELPER (Asia/Jakarta, UTC+7)
// ==========================================
function getIndonesianCurrentDate(): Date {
  const now = new Date();
  // Get time in UTC+7 (WIB)
  const utc = now.getTime() + now.getTimezoneOffset() * 60000;
  return new Date(utc + 7 * 3600000);
}

function formatIndonesianDate(date: Date): { dayName: string; formatted: string; dayOfWeek: number; yyyyMmDd: string } {
  const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
  const months = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ];

  const dayOfWeek = date.getDay() === 0 ? 7 : date.getDay(); // 1=Senin ... 7=Minggu
  const dayName = days[date.getDay()];
  const dayNum = date.getDate();
  const monthName = months[date.getMonth()];
  const year = date.getFullYear();

  const pad = (n: number) => String(n).padStart(2, '0');
  const yyyyMmDd = `${year}-${pad(date.getMonth() + 1)}-${pad(dayNum)}`;

  return {
    dayName,
    formatted: `${dayName}, ${dayNum} ${monthName} ${year}`,
    dayOfWeek,
    yyyyMmDd,
  };
}

// ==========================================
// PUBLIC ENDPOINTS
// ==========================================

// Class info
apiRouter.get('/info', async (_req, res) => {
  res.json({
    university: 'UNIVERSITAS NUSANTARA PGRI',
    faculty: 'Fakultas Teknik',
    studyProgram: 'Teknik Informatika',
    classCode: '1C',
    totalStudents: 35,
    tagline: '35 MAHASISWA • 1 KELAS • 1 CERITA',
  });
});

// "Besok Kuliah Apa?"
apiRouter.get('/schedule/tomorrow', async (_req, res) => {
  try {
    const today = getIndonesianCurrentDate();
    const tomorrow = new Date(today.getTime() + 24 * 3600000);
    const { dayName, formatted, dayOfWeek, yyyyMmDd } = formatIndonesianDate(tomorrow);

    // Query schedules that either recur on tomorrow's day of week OR specific date equals tomorrow
    const schedules = await query(`
      SELECT 
        s.id,
        s.dayOfWeek,
        s.startTime,
        s.endTime,
        s.room,
        s.recurrenceType,
        s.specificDate,
        c.name AS courseName,
        c.code AS courseCode,
        c.sks AS courseSks,
        l.name AS lecturerName,
        l.room AS lecturerRoom
      FROM schedules s
      JOIN courses c ON s.courseId = c.id
      JOIN lecturers l ON s.lecturerId = l.id
      WHERE (s.recurrenceType = 'WEEKLY' AND s.dayOfWeek = ?)
         OR (s.recurrenceType = 'SPECIFIC_DATE' AND s.specificDate = ?)
      ORDER BY s.startTime ASC
    `, [dayOfWeek, yyyyMmDd]);

    res.json({
      dayName,
      dateFormatted: formatted,
      isoDate: yyyyMmDd,
      hasClasses: schedules.length > 0,
      classes: schedules,
    });
  } catch (error) {
    console.error('Error fetching tomorrow schedule:', error);
    res.status(500).json({ error: 'Gagal memuat jadwal kuliah besok.' });
  }
});

// Calendar schedules for specific month/year
apiRouter.get('/schedule/calendar', async (req, res) => {
  try {
    const today = getIndonesianCurrentDate();
    const year = parseInt(req.query.year as string, 10) || today.getFullYear();
    const month = parseInt(req.query.month as string, 10) || today.getMonth() + 1; // 1-12

    if (month < 1 || month > 12 || year < 2000 || year > 2100) {
      res.status(400).json({ error: 'Bulan atau tahun tidak valid.' });
      return;
    }

    // Days in month
    const totalDays = new Date(year, month, 0).getDate();
    const pad = (n: number) => String(n).padStart(2, '0');

    // All schedules
    const allSchedules = await query(`
      SELECT 
        s.id,
        s.dayOfWeek,
        s.startTime,
        s.endTime,
        s.room,
        s.recurrenceType,
        s.specificDate,
        c.name AS courseName,
        c.code AS courseCode,
        c.sks AS courseSks,
        l.name AS lecturerName
      FROM schedules s
      JOIN courses c ON s.courseId = c.id
      JOIN lecturers l ON s.lecturerId = l.id
      ORDER BY s.startTime ASC
    `);

    // Map each date in month to schedules
    const calendarDays: Array<{
      date: string;
      dayNumber: number;
      dayOfWeek: number;
      hasClasses: boolean;
      schedules: any[];
    }> = [];

    for (let day = 1; day <= totalDays; day++) {
      const curDate = new Date(year, month - 1, day);
      const dayOfWeek = curDate.getDay() === 0 ? 7 : curDate.getDay();
      const dateStr = `${year}-${pad(month)}-${pad(day)}`;

      const matching = allSchedules.filter((s: any) => {
        if (s.recurrenceType === 'WEEKLY') {
          return s.dayOfWeek === dayOfWeek;
        }
        return s.specificDate === dateStr;
      });

      calendarDays.push({
        date: dateStr,
        dayNumber: day,
        dayOfWeek,
        hasClasses: matching.length > 0,
        schedules: matching,
      });
    }

    res.json({
      year,
      month,
      days: calendarDays,
    });
  } catch (error) {
    console.error('Error generating calendar:', error);
    res.status(500).json({ error: 'Gagal memuat kalender jadwal.' });
  }
});

// All schedules
apiRouter.get('/schedules', async (_req, res) => {
  try {
    const schedules = await query(`
      SELECT 
        s.id,
        s.dayOfWeek,
        s.startTime,
        s.endTime,
        s.room,
        s.recurrenceType,
        s.specificDate,
        s.courseId,
        s.lecturerId,
        c.name AS courseName,
        c.code AS courseCode,
        c.sks AS courseSks,
        c.description AS courseDescription,
        l.name AS lecturerName,
        l.room AS lecturerRoom
      FROM schedules s
      JOIN courses c ON s.courseId = c.id
      JOIN lecturers l ON s.lecturerId = l.id
      ORDER BY s.dayOfWeek ASC, s.startTime ASC
    `);
    res.json(schedules);
  } catch (error) {
    console.error('Error fetching schedules:', error);
    res.status(500).json({ error: 'Gagal memuat daftar jadwal.' });
  }
});

// Courses
apiRouter.get('/courses', async (_req, res) => {
  try {
    const courses = await query(`
      SELECT 
        c.id, c.name, c.code, c.sks, c.description, c.createdAt,
        (SELECT STRING_AGG(DISTINCT l.name, ', ') 
         FROM schedules s 
         JOIN lecturers l ON s.lecturerId = l.id 
         WHERE s.courseId = c.id) AS lecturerNames
      FROM courses c
      ORDER BY c.code ASC
    `);
    res.json(courses);
  } catch (error) {
    console.error('Error fetching courses:', error);
    res.status(500).json({ error: 'Gagal memuat mata kuliah.' });
  }
});

// Lecturers
apiRouter.get('/lecturers', async (_req, res) => {
  try {
    const lecturers = await query(`
      SELECT 
        l.id, l.name, l.email, l.room, l.createdAt,
        (SELECT STRING_AGG(DISTINCT c.name, ', ') 
         FROM schedules s 
         JOIN courses c ON s.courseId = c.id 
         WHERE s.lecturerId = l.id) AS courseNames
      FROM lecturers l
      ORDER BY l.name ASC
    `);
    res.json(lecturers);
  } catch (error) {
    console.error('Error fetching lecturers:', error);
    res.status(500).json({ error: 'Gagal memuat daftar dosen.' });
  }
});

// Students (Struktur Kelas)
apiRouter.get('/students', async (_req, res) => {
  try {
    const students = await query(`
      SELECT id, name, npm, position, division, orderIndex
      FROM students
      ORDER BY orderIndex ASC
    `);
    res.json(students);
  } catch (error) {
    console.error('Error fetching students:', error);
    res.status(500).json({ error: 'Gagal memuat data mahasiswa.' });
  }
});

// Announcements (Published only for public)
apiRouter.get('/announcements', async (_req, res) => {
  try {
    const announcements = await query(`
      SELECT id, title, content, category, createdAt, updatedAt
      FROM announcements
      WHERE published = 1
      ORDER BY createdAt DESC
    `);
    res.json(announcements);
  } catch (error) {
    console.error('Error fetching announcements:', error);
    res.status(500).json({ error: 'Gagal memuat pengumuman.' });
  }
});

// Audio Stream Endpoint (High speed local MP3 stream with range support)
apiRouter.get('/audio/stream', async (req, res) => {
  const localAudioPath = path.join(process.cwd(), 'public', 'audio', 'music.mp3');
  if (fs.existsSync(localAudioPath)) {
    const stat = fs.statSync(localAudioPath);
    const fileSize = stat.size;
    const range = req.headers.range;

    if (range) {
      const parts = range.replace(/bytes=/, '').split('-');
      const start = parseInt(parts[0], 10);
      const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
      const chunksize = end - start + 1;
      const file = fs.createReadStream(localAudioPath, { start, end });
      const head = {
        'Content-Range': `bytes ${start}-${end}/${fileSize}`,
        'Accept-Ranges': 'bytes',
        'Content-Length': chunksize,
        'Content-Type': 'audio/mpeg',
      };
      res.writeHead(206, head);
      file.pipe(res);
    } else {
      const head = {
        'Content-Length': fileSize,
        'Content-Type': 'audio/mpeg',
        'Accept-Ranges': 'bytes',
      };
      res.writeHead(200, head);
      fs.createReadStream(localAudioPath).pipe(res);
    }
  } else {
    // If not local, redirect to original source
    res.redirect('https://files.catbox.moe/fd63ue.mp3');
  }
});

// ==========================================
// AUTHENTICATION ENDPOINTS
// ==========================================

const loginSchema = z.object({
  email: z.string().min(1, 'Username atau email wajib diisi'),
  password: z.string().min(1, 'Password wajib diisi'),
});

function extractToken(req: Request): string | null {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.slice(7).trim();
  }
  return req.cookies?.unp_session || null;
}

apiRouter.post('/auth/login', loginLimiter, async (req: Request, res: Response) => {
  try {
    const parseResult = loginSchema.safeParse(req.body);
    if (!parseResult.success) {
      res.status(400).json({ error: 'Username/email atau password tidak valid.' });
      return;
    }

    const { email: identifier, password } = parseResult.data;
    const cleanId = identifier.trim();

    // Use the same credential/session system as the main server auth.
    // This prevents the old DB-user login path from creating a session
    // that is incompatible with the admin dashboard.
    if (!checkCredentials(cleanId, password)) {
      res.status(401).json({ error: 'Username atau password salah.' });
      return;
    }

    const sessionToken = await createSession(cleanId);

    res.cookie('unp_session', sessionToken, {
      httpOnly: true,
      secure: true,
      sameSite: 'none',
      maxAge: 7 * 24 * 3600 * 1000,
      path: '/',
    });

    logAuditAction('admin-1', cleanId, 'ADMIN LOGIN', 'Login berhasil dari portal admin');

    res.json({
      message: 'Login berhasil',
      token: sessionToken,
      user: {
        id: 'admin-1',
        email: cleanId,
        role: 'ADMIN',
      },
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Terjadi kesalahan sistem saat proses login.' });
  }
});

apiRouter.post('/auth/logout', async (req: Request, res: Response) => {
  const token = extractToken(req);
  if (token) {
    const user = verifySession(token);
    if (user) {
      logAuditAction(user.id, user.email, 'ADMIN LOGOUT', 'Admin keluar dari sistem');
    }
    destroySession(token);
  }
  res.clearCookie('unp_session', { path: '/', sameSite: 'none', secure: true });
  res.json({ message: 'Logout berhasil' });
});

apiRouter.get('/auth/me', async (req: Request, res: Response) => {
  const token = extractToken(req);
  if (!token) {
    res.status(401).json({ error: 'Belum login' });
    return;
  }
  const user = verifySession(token);
  if (!user) {
    res.status(401).json({ error: 'Sesi kedaluwarsa atau tidak valid' });
    return;
  }
  res.json({ user });
});

// ==========================================
// ADMIN PROTECTED ENDPOINTS
// ==========================================

// Admin stats
apiRouter.get('/admin/stats', requireAdminAuth, async (_req, res) => {
  try {
    const coursesCount = (await queryOne<{ count: number }>('SELECT COUNT(*) AS count FROM courses'))?.count || 0;
    const lecturersCount = (await queryOne<{ count: number }>('SELECT COUNT(*) AS count FROM lecturers'))?.count || 0;
    const schedulesCount = (await queryOne<{ count: number }>('SELECT COUNT(*) AS count FROM schedules'))?.count || 0;
    const studentsCount = (await queryOne<{ count: number }>('SELECT COUNT(*) AS count FROM students'))?.count || 0;
    const announcementsCount = (await queryOne<{ count: number }>('SELECT COUNT(*) AS count FROM announcements'))?.count || 0;

    res.json({
      coursesCount,
      lecturersCount,
      schedulesCount,
      studentsCount,
      announcementsCount,
    });
  } catch (error) {
    console.error('Stats error:', error);
    res.status(500).json({ error: 'Gagal memuat statistik admin.' });
  }
});

// Audit logs
apiRouter.get('/admin/audit-logs', requireAdminAuth, async (_req, res) => {
  try {
    const logs = await query('SELECT * FROM audit_logs ORDER BY createdAt DESC LIMIT 100');
    res.json(logs);
  } catch (error) {
    console.error('Audit logs error:', error);
    res.status(500).json({ error: 'Gagal memuat audit log.' });
  }
});

// Admin announcements (includes drafts)
apiRouter.get('/admin/announcements', requireAdminAuth, async (_req, res) => {
  try {
    const list = await query('SELECT * FROM announcements ORDER BY createdAt DESC');
    res.json(list);
  } catch (error) {
    console.error('Admin announcements error:', error);
    res.status(500).json({ error: 'Gagal memuat pengumuman admin.' });
  }
});

const announcementSchema = z.object({
  title: z.string().min(3, 'Judul minimal 3 karakter').max(200),
  content: z.string().min(5, 'Konten minimal 5 karakter'),
  category: z.string().default('Umum'),
  published: z.number().min(0).max(1).default(1),
});

apiRouter.post('/admin/announcements', requireAdminAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const parsed = announcementSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues[0]?.message || 'Input tidak valid' });
      return;
    }
    const { title, content, category, published } = parsed.data;
    const id = crypto.randomUUID();
    const now = new Date().toISOString();

    await run(
      `INSERT INTO announcements (id, title, content, category, published, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [id, title, content, category, published, now, now]
    );

    logAuditAction(req.adminUser!.id, req.adminUser!.email, 'CREATE ANNOUNCEMENT', `Judul: ${title}`);
    res.status(201).json({ id, message: 'Pengumuman berhasil dibuat' });
  } catch (error) {
    console.error('Create announcement error:', error);
    res.status(500).json({ error: 'Gagal membuat pengumuman.' });
  }
});

apiRouter.put('/admin/announcements/:id', requireAdminAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const parsed = announcementSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues[0]?.message || 'Input tidak valid' });
      return;
    }
    const { title, content, category, published } = parsed.data;
    const now = new Date().toISOString();

    await run(
      `UPDATE announcements SET title = ?, content = ?, category = ?, published = ?, updatedAt = ? WHERE id = ?`,
      [title, content, category, published, now, req.params.id]
    );

    logAuditAction(req.adminUser!.id, req.adminUser!.email, 'UPDATE ANNOUNCEMENT', `ID: ${req.params.id} | Judul: ${title}`);
    res.json({ message: 'Pengumuman berhasil diperbarui' });
  } catch (error) {
    console.error('Update announcement error:', error);
    res.status(500).json({ error: 'Gagal memperbarui pengumuman.' });
  }
});

apiRouter.delete('/admin/announcements/:id', requireAdminAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    await run('DELETE FROM announcements WHERE id = ?', [req.params.id]);
    logAuditAction(req.adminUser!.id, req.adminUser!.email, 'DELETE ANNOUNCEMENT', `ID: ${req.params.id}`);
    res.json({ message: 'Pengumuman berhasil dihapus' });
  } catch (error) {
    console.error('Delete announcement error:', error);
    res.status(500).json({ error: 'Gagal menghapus pengumuman.' });
  }
});

// CRUD Courses
const courseSchema = z.object({
  name: z.string().min(3, 'Nama mata kuliah minimal 3 karakter'),
  code: z.string().min(2, 'Kode mata kuliah minimal 2 karakter').max(20),
  sks: z.coerce.number().min(1, 'SKS minimal 1').max(6, 'SKS maksimal 6'),
  description: z.string().optional().nullable(),
});

apiRouter.post('/admin/courses', requireAdminAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const parsed = courseSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues[0]?.message || 'Input tidak valid' });
      return;
    }
    const { name, code, sks, description } = parsed.data;
    const id = crypto.randomUUID();
    const now = new Date().toISOString();

    await run(
      `INSERT INTO courses (id, name, code, sks, description, createdAt) VALUES (?, ?, ?, ?, ?, ?)`,
      [id, name, code, sks, description || null, now]
    );

    logAuditAction(req.adminUser!.id, req.adminUser!.email, 'CREATE COURSE', `Mata Kuliah: ${name} (${code})`);
    res.status(201).json({ id, message: 'Mata kuliah berhasil ditambahkan' });
  } catch (error) {
    console.error('Create course error:', error);
    res.status(500).json({ error: 'Gagal menambahkan mata kuliah.' });
  }
});

apiRouter.put('/admin/courses/:id', requireAdminAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const parsed = courseSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues[0]?.message || 'Input tidak valid' });
      return;
    }
    const { name, code, sks, description } = parsed.data;

    await run(
      `UPDATE courses SET name = ?, code = ?, sks = ?, description = ? WHERE id = ?`,
      [name, code, sks, description || null, req.params.id]
    );

    logAuditAction(req.adminUser!.id, req.adminUser!.email, 'UPDATE COURSE', `ID: ${req.params.id} | ${name} (${code})`);
    res.json({ message: 'Mata kuliah berhasil diperbarui' });
  } catch (error) {
    console.error('Update course error:', error);
    res.status(500).json({ error: 'Gagal memperbarui mata kuliah.' });
  }
});

apiRouter.delete('/admin/courses/:id', requireAdminAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    await run('DELETE FROM courses WHERE id = ?', [req.params.id]);
    logAuditAction(req.adminUser!.id, req.adminUser!.email, 'DELETE COURSE', `ID: ${req.params.id}`);
    res.json({ message: 'Mata kuliah berhasil dihapus' });
  } catch (error) {
    console.error('Delete course error:', error);
    res.status(500).json({ error: 'Gagal menghapus mata kuliah.' });
  }
});

// CRUD Lecturers
const lecturerSchema = z.object({
  name: z.string().min(3, 'Nama dosen minimal 3 karakter'),
  email: z.string().email('Format email tidak valid').optional().nullable().or(z.literal('')),
  room: z.string().optional().nullable(),
});

apiRouter.post('/admin/lecturers', requireAdminAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const parsed = lecturerSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues[0]?.message || 'Input tidak valid' });
      return;
    }
    const { name, email, room } = parsed.data;
    const id = crypto.randomUUID();
    const now = new Date().toISOString();

    await run(
      `INSERT INTO lecturers (id, name, email, room, createdAt) VALUES (?, ?, ?, ?, ?)`,
      [id, name, email || null, room || null, now]
    );

    logAuditAction(req.adminUser!.id, req.adminUser!.email, 'CREATE LECTURER', `Nama: ${name}`);
    res.status(201).json({ id, message: 'Dosen berhasil ditambahkan' });
  } catch (error) {
    console.error('Create lecturer error:', error);
    res.status(500).json({ error: 'Gagal menambahkan dosen.' });
  }
});

apiRouter.put('/admin/lecturers/:id', requireAdminAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const parsed = lecturerSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues[0]?.message || 'Input tidak valid' });
      return;
    }
    const { name, email, room } = parsed.data;

    await run(
      `UPDATE lecturers SET name = ?, email = ?, room = ? WHERE id = ?`,
      [name, email || null, room || null, req.params.id]
    );

    logAuditAction(req.adminUser!.id, req.adminUser!.email, 'UPDATE LECTURER', `ID: ${req.params.id} | Nama: ${name}`);
    res.json({ message: 'Data dosen berhasil diperbarui' });
  } catch (error) {
    console.error('Update lecturer error:', error);
    res.status(500).json({ error: 'Gagal memperbarui data dosen.' });
  }
});

apiRouter.delete('/admin/lecturers/:id', requireAdminAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    await run('DELETE FROM lecturers WHERE id = ?', [req.params.id]);
    logAuditAction(req.adminUser!.id, req.adminUser!.email, 'DELETE LECTURER', `ID: ${req.params.id}`);
    res.json({ message: 'Dosen berhasil dihapus' });
  } catch (error) {
    console.error('Delete lecturer error:', error);
    res.status(500).json({ error: 'Gagal menghapus data dosen.' });
  }
});

// CRUD Schedules with Conflict Detection
const scheduleSchema = z.object({
  courseId: z.string().min(1, 'Mata kuliah wajib dipilih'),
  lecturerId: z.string().min(1, 'Dosen wajib dipilih'),
  dayOfWeek: z.coerce.number().min(1).max(7),
  startTime: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, 'Format jam mulai harus HH:mm (contoh 08:00)'),
  endTime: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, 'Format jam selesai harus HH:mm (contoh 10:30)'),
  room: z.string().min(1, 'Ruangan wajib diisi'),
  recurrenceType: z.enum(['WEEKLY', 'SPECIFIC_DATE']).default('WEEKLY'),
  specificDate: z.string().optional().nullable(),
  forceConflict: z.boolean().optional().default(false), // Admin choice flag
}).refine(data => data.startTime < data.endTime, {
  message: 'Jam selesai harus lebih besar daripada jam mulai.',
  path: ['endTime'],
});

async function checkScheduleConflict(
  dayOfWeek: number,
  startTime: string,
  endTime: string,
  room: string,
  recurrenceType: string,
  specificDate?: string | null,
  excludeId?: string
): Promise<{ hasConflict: boolean; conflictingItem?: any }> {
  let querySql = `
    SELECT 
      s.id, s.dayOfWeek, s.startTime, s.endTime, s.room, s.recurrenceType, s.specificDate,
      c.name AS courseName, l.name AS lecturerName
    FROM schedules s
    JOIN courses c ON s.courseId = c.id
    JOIN lecturers l ON s.lecturerId = l.id
    WHERE s.dayOfWeek = ?
  `;
  const params: any[] = [dayOfWeek];

  if (excludeId) {
    querySql += ` AND s.id != ?`;
    params.push(excludeId);
  }

  const existingList = await query(querySql, params);

  for (const item of existingList) {
    // Check if dates match (if specific date)
    if (recurrenceType === 'SPECIFIC_DATE' && item.recurrenceType === 'SPECIFIC_DATE') {
      if (item.specificDate !== specificDate) continue;
    }

    // Time overlap check: max(start1, start2) < min(end1, end2)
    const isOverlapping = (startTime < item.endTime) && (endTime > item.startTime);
    if (isOverlapping) {
      // Conflict if same room OR same class
      return {
        hasConflict: true,
        conflictingItem: item,
      };
    }
  }

  return { hasConflict: false };
}

apiRouter.post('/admin/schedules', requireAdminAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const parsed = scheduleSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues[0]?.message || 'Input tidak valid' });
      return;
    }
    const data = parsed.data;

    // Check conflict unless admin explicitly approved
    if (!data.forceConflict) {
      const conflict = await checkScheduleConflict(
        data.dayOfWeek,
        data.startTime,
        data.endTime,
        data.room,
        data.recurrenceType,
        data.specificDate
      );

      if (conflict.hasConflict) {
        res.status(409).json({
          conflict: true,
          error: `Jadwal bertabrakan dengan jadwal yang sudah ada: ${conflict.conflictingItem.courseName} (${conflict.conflictingItem.startTime} - ${conflict.conflictingItem.endTime} di ${conflict.conflictingItem.room}). Silakan sesuaikan jam/ruangan atau konfirmasi untuk tetap menyimpan.`,
          conflictingItem: conflict.conflictingItem,
        });
        return;
      }
    }

    const id = crypto.randomUUID();
    const now = new Date().toISOString();

    await run(
      `INSERT INTO schedules (id, courseId, lecturerId, dayOfWeek, startTime, endTime, room, recurrenceType, specificDate, createdAt)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [id, data.courseId, data.lecturerId, data.dayOfWeek, data.startTime, data.endTime, data.room, data.recurrenceType, data.specificDate || null, now]
    );

    logAuditAction(req.adminUser!.id, req.adminUser!.email, 'CREATE SCHEDULE', `Hari ${data.dayOfWeek}, ${data.startTime}-${data.endTime}, Ruang: ${data.room}`);
    res.status(201).json({ id, message: 'Jadwal berhasil dibuat' });
  } catch (error) {
    console.error('Create schedule error:', error);
    res.status(500).json({ error: 'Gagal membuat jadwal.' });
  }
});

apiRouter.put('/admin/schedules/:id', requireAdminAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const parsed = scheduleSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues[0]?.message || 'Input tidak valid' });
      return;
    }
    const data = parsed.data;

    if (!data.forceConflict) {
      const conflict = await checkScheduleConflict(
        data.dayOfWeek,
        data.startTime,
        data.endTime,
        data.room,
        data.recurrenceType,
        data.specificDate,
        req.params.id
      );

      if (conflict.hasConflict) {
        res.status(409).json({
          conflict: true,
          error: `Jadwal bertabrakan dengan jadwal yang sudah ada: ${conflict.conflictingItem.courseName} (${conflict.conflictingItem.startTime} - ${conflict.conflictingItem.endTime} di ${conflict.conflictingItem.room}).`,
          conflictingItem: conflict.conflictingItem,
        });
        return;
      }
    }

    await run(
      `UPDATE schedules SET courseId = ?, lecturerId = ?, dayOfWeek = ?, startTime = ?, endTime = ?, room = ?, recurrenceType = ?, specificDate = ?
       WHERE id = ?`,
      [data.courseId, data.lecturerId, data.dayOfWeek, data.startTime, data.endTime, data.room, data.recurrenceType, data.specificDate || null, req.params.id]
    );

    logAuditAction(req.adminUser!.id, req.adminUser!.email, 'UPDATE SCHEDULE', `ID: ${req.params.id}`);
    res.json({ message: 'Jadwal berhasil diperbarui' });
  } catch (error) {
    console.error('Update schedule error:', error);
    res.status(500).json({ error: 'Gagal memperbarui jadwal.' });
  }
});

apiRouter.delete('/admin/schedules/:id', requireAdminAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    await run('DELETE FROM schedules WHERE id = ?', [req.params.id]);
    logAuditAction(req.adminUser!.id, req.adminUser!.email, 'DELETE SCHEDULE', `ID: ${req.params.id}`);
    res.json({ message: 'Jadwal berhasil dihapus' });
  } catch (error) {
    console.error('Delete schedule error:', error);
    res.status(500).json({ error: 'Gagal menghapus jadwal.' });
  }
});

// Update Student (Struktur Kelas)
const studentSchema = z.object({
  name: z.string().min(2, 'Nama mahasiswa minimal 2 karakter').max(100),
  npm: z.string().min(5, 'NPM minimal 5 karakter').max(30),
  position: z.string().min(2, 'Jabatan minimal 2 karakter').max(50),
  division: z.string().min(2, 'Divisi minimal 2 karakter').max(50),
});

apiRouter.put('/admin/students/:id', requireAdminAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const parsed = studentSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues[0]?.message || 'Input tidak valid' });
      return;
    }
    const { name, npm, position, division } = parsed.data;

    await run(
      `UPDATE students SET name = ?, npm = ?, position = ?, division = ? WHERE id = ?`,
      [name, npm, position, division, req.params.id]
    );

    logAuditAction(req.adminUser!.id, req.adminUser!.email, 'UPDATE STUDENT', `ID: ${req.params.id} | Nama: ${name} (${npm}) - ${position}`);
    res.json({ message: 'Data mahasiswa berhasil diperbarui' });
  } catch (error) {
    console.error('Update student error:', error);
    res.status(500).json({ error: 'Gagal memperbarui data mahasiswa.' });
  }
});
