import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import cookieParser from 'cookie-parser';
import helmet from 'helmet';
import dotenv from 'dotenv';
import { z } from 'zod';
import {
  createSession,
  destroySession,
  verifySession,
  requireAdminAuth,
  loginLimiter,
  AuthenticatedRequest,
  checkCredentials,
} from './server/auth';
import { apiRouter } from './server/routes';

dotenv.config();

const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const adminEmail = process.env.ADMIN_EMAIL || '(not set)';

const app = express();

app.set('trust proxy', 1);
app.use(
  helmet({
    contentSecurityPolicy: false,
    frameguard: false,
    crossOriginResourcePolicy: false,
    crossOriginOpenerPolicy: false,
    crossOriginEmbedderPolicy: false,
  })
);

app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));
app.use(cookieParser(process.env.AUTH_SECRET || 'unp-secret-2026'));

// Full database-backed API. This must be mounted after body/cookie middleware.
app.use('/api', apiRouter);

console.log('[SERVER] 🚀 Starting...');
console.log(`[SERVER] 📝 Admin email configured: ${adminEmail}`);

// ==========================================
// PUBLIC INFO & HEALTH
// ==========================================
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({ status: 'ok', serverTime: new Date().toISOString() });
});

app.get('/api/info', (_req: Request, res: Response) => {
  res.json({
    university: 'UNIVERSITAS NUSANTARA PGRI KEDIRI',
    faculty: 'Fakultas Teknik',
    studyProgram: 'Teknik Informatika',
    classCode: '1C',
    totalStudents: 35,
    tagline: '35 MAHASISWA • 1 KELAS • 1 CERITA',
  });
});

// ==========================================
// AUDIO STREAM ENDPOINT
// ==========================================
app.get('/api/audio/stream', (req: Request, res: Response) => {
  const localAudioPath = path.join(process.cwd(), 'public', 'audio', 'music.mp3');
  if (fs.existsSync(localAudioPath)) {
    const stat = fs.statSync(localAudioPath);
    const fileSize = stat.size;
    const range = req.headers.range;

    if (range) {
      const parts = range.replace(/bytes=/, '').split('-');
      const start = parseInt(parts[0], 10);
      const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
      const chunksize = end - start + 1;
      const file = fs.createReadStream(localAudioPath, { start, end });
      const head = {
        'Content-Range': `bytes ${start}-${end}/${fileSize}`,
        'Accept-Ranges': 'bytes',
        'Content-Length': chunksize,
        'Content-Type': 'audio/mpeg',
      };
      res.writeHead(206, head);
      file.pipe(res);
    } else {
      const head = {
        'Content-Length': fileSize,
        'Content-Type': 'audio/mpeg',
        'Accept-Ranges': 'bytes',
      };
      res.writeHead(200, head);
      fs.createReadStream(localAudioPath).pipe(res);
    }
  } else {
    res.redirect('https://files.catbox.moe/fd63ue.mp3');
  }
});

// Authentication endpoints are implemented by apiRouter in server/routes.ts.
// Keeping a single auth implementation prevents route-order/session mismatches.

// ==========================================
// STATIC FILES & VITE
// ==========================================
if (process.env.NETLIFY !== 'true') {
  const distPath = [
    path.join(process.cwd(), 'dist'),
    path.join(__dirname, '..', 'dist'),
    __dirname,
  ].find((p) => fs.existsSync(path.join(p, 'index.html'))) || path.join(process.cwd(), 'dist');

  app.use(express.static(distPath));
  app.get('*', (_req: Request, res: Response) => {
    res.sendFile(path.join(distPath, 'index.html'));
  });

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[SERVER] ✅ Running at http://0.0.0.0:${PORT}`);
  });
}

export { app };
