import type { Handler } from '@netlify/functions';
import serverless from 'serverless-http';
import { app } from '../server';

const wrapped = serverless(app);
export const handler: Handler = (event, context) => wrapped(event as any, context as any);
