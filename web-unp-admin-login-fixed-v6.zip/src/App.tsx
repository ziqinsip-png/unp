/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AuthProvider } from './context/AuthContext.tsx';
import { Navbar } from './components/Navbar.tsx';
import { Hero } from './components/Hero.tsx';
import { TomorrowWidget } from './components/TomorrowWidget.tsx';
import { ScheduleView } from './components/ScheduleView.tsx';
import { ClassStructure } from './components/ClassStructure.tsx';
import { CoursesAndLecturers } from './components/CoursesAndLecturers.tsx';
import { Announcements } from './components/Announcements.tsx';
import { AdminModal } from './components/AdminModal.tsx';
import { Footer } from './components/Footer.tsx';
import { MusicPlayer } from './components/MusicPlayer.tsx';
import { api } from './services/api.ts';

export default function App() {
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [dataVersion, setDataVersion] = useState(0);
  const [classStats, setClassStats] = useState({
    studentsCount: 35,
    coursesCount: 6,
    lecturersCount: 5,
    schedulesCount: 7,
  });

  const loadStats = async () => {
    try {
      const [students, courses, lecturers, schedules] = await Promise.all([
        api.getStudents(),
        api.getCourses(),
        api.getLecturers(),
        api.getSchedules(),
      ]);
      setClassStats({
        studentsCount: students.length,
        coursesCount: courses.length,
        lecturersCount: lecturers.length,
        schedulesCount: schedules.length,
      });
    } catch (err) {
      console.error('Failed to load portal stats:', err);
    }
  };

  useEffect(() => {
    loadStats();
  }, [dataVersion]);

  const handleNavigate = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleDataChanged = () => {
    setDataVersion((prev) => prev + 1);
  };

  return (
    <AuthProvider>
      <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
        
        {/* Navigation Bar */}
        <Navbar
          onOpenAdmin={() => setIsAdminModalOpen(true)}
          onNavigate={handleNavigate}
        />

        {/* Main Content Sections */}
        <main className="flex-1">
          {/* Hero Section with interactive terminal */}
          <Hero
            onNavigate={handleNavigate}
            stats={classStats}
          />

          {/* Tomorrow's Schedule Resolver */}
          <TomorrowWidget
            key={`tomorrow-${dataVersion}`}
            onViewAllSchedules={() => handleNavigate('jadwal')}
          />

          {/* Schedule & Calendar View */}
          <ScheduleView
            key={`schedules-${dataVersion}`}
          />

          {/* Class Structure & 35 Students Directory */}
          <ClassStructure
            key={`students-${dataVersion}`}
          />

          {/* Courses & Lecturers */}
          <CoursesAndLecturers
            key={`courses-${dataVersion}`}
          />

          {/* Announcements Board */}
          <Announcements
            key={`announcements-${dataVersion}`}
          />
        </main>

        {/* Footer */}
        <div className="pb-28">
          <Footer
            onOpenAdmin={() => setIsAdminModalOpen(true)}
            onNavigate={handleNavigate}
          />
        </div>

        {/* Protected Admin Modal & Dashboard */}
        <AdminModal
          isOpen={isAdminModalOpen}
          onClose={() => setIsAdminModalOpen(false)}
          onDataChanged={handleDataChanged}
        />

        {/* Interactive Audio Player with Progress Animation */}
        <MusicPlayer />

      </div>
    </AuthProvider>
  );
}

