export interface User {
  id: string;
  email: string;
  role: string;
}

export interface Student {
  id: string;
  name: string;
  npm: string;
  position: string;
  division: string;
  orderIndex: number;
}

export interface Course {
  id: string;
  name: string;
  code: string;
  sks: number;
  description?: string;
  lecturerNames?: string;
  createdAt: string;
}

export interface Lecturer {
  id: string;
  name: string;
  email?: string;
  room?: string;
  courseNames?: string;
  createdAt: string;
}

export interface ScheduleItem {
  id: string;
  courseId: string;
  lecturerId: string;
  dayOfWeek: number; // 1 = Senin ... 7 = Minggu
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  room: string;
  recurrenceType: 'WEEKLY' | 'SPECIFIC_DATE';
  specificDate?: string | null;
  courseName: string;
  courseCode: string;
  courseSks: number;
  courseDescription?: string;
  lecturerName: string;
  lecturerRoom?: string;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  category: string;
  published?: number;
  createdAt: string;
  updatedAt: string;
}

export interface AuditLog {
  id: string;
  userId: string;
  userEmail: string;
  action: string;
  details?: string;
  createdAt: string;
}

export interface TomorrowScheduleResponse {
  dayName: string;
  dateFormatted: string;
  isoDate: string;
  hasClasses: boolean;
  classes: ScheduleItem[];
}

export interface CalendarDay {
  date: string;
  dayNumber: number;
  dayOfWeek: number;
  hasClasses: boolean;
  schedules: ScheduleItem[];
}

export interface CalendarResponse {
  year: number;
  month: number;
  days: CalendarDay[];
}

export interface AdminStats {
  coursesCount: number;
  lecturersCount: number;
  schedulesCount: number;
  studentsCount: number;
  announcementsCount: number;
}
