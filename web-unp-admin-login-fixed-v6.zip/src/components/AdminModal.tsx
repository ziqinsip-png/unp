import React, { useState, useEffect } from 'react';
import {
  X, Shield, Lock, Mail, AlertTriangle, CheckCircle, RefreshCw,
  Plus, Edit2, Trash2, Calendar, BookOpen, User, Users, Bell, Activity, Clock
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';
import { api } from '../services/api.ts';
import {
  AdminStats, Announcement, AuditLog, Course, Lecturer, ScheduleItem, Student
} from '../types.ts';

interface AdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDataChanged?: () => void;
}

export const AdminModal: React.FC<AdminModalProps> = ({ isOpen, onClose, onDataChanged }) => {
  const { user, isAdmin, login, logout } = useAuth();

  // Login Form State (starts completely empty, no pre-filled credentials)
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginLoading, setLoginLoading] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);

  // Admin Workspace Tabs: 'stats' | 'schedules' | 'courses' | 'lecturers' | 'students' | 'announcements' | 'audit'
  const [activeTab, setActiveTab] = useState<'stats' | 'schedules' | 'courses' | 'lecturers' | 'students' | 'announcements' | 'audit'>('stats');

  // Admin Data states
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [schedules, setSchedules] = useState<ScheduleItem[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [lecturers, setLecturers] = useState<Lecturer[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [loadingData, setLoadingData] = useState(false);
  const [actionMessage, setActionMessage] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  // Modal Sub-dialogs (Forms for Add / Edit)
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);
  const [isCourseFormOpen, setIsCourseFormOpen] = useState(false);
  const [courseForm, setCourseForm] = useState({ name: '', code: '', sks: 3, description: '' });

  const [editingLecturer, setEditingLecturer] = useState<Lecturer | null>(null);
  const [isLecturerFormOpen, setIsLecturerFormOpen] = useState(false);
  const [lecturerForm, setLecturerForm] = useState({ name: '', email: '', room: '' });

  const [editingSchedule, setEditingSchedule] = useState<ScheduleItem | null>(null);
  const [isScheduleFormOpen, setIsScheduleFormOpen] = useState(false);
  const [scheduleForm, setScheduleForm] = useState({
    courseId: '',
    lecturerId: '',
    dayOfWeek: 1,
    startTime: '08:00',
    endTime: '10:30',
    room: '',
    recurrenceType: 'WEEKLY' as 'WEEKLY' | 'SPECIFIC_DATE',
    specificDate: '',
  });

  // Conflict state when saving schedule
  const [conflictModalData, setConflictModalData] = useState<{
    message: string;
    pendingPayload: any;
    isEditing: boolean;
    editId?: string;
  } | null>(null);

  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [isStudentFormOpen, setIsStudentFormOpen] = useState(false);
  const [studentForm, setStudentForm] = useState({ name: '', npm: '', position: '', division: '' });

  const [editingAnnouncement, setEditingAnnouncement] = useState<Announcement | null>(null);
  const [isAnnouncementFormOpen, setIsAnnouncementFormOpen] = useState(false);
  const [announcementForm, setAnnouncementForm] = useState({
    title: '',
    content: '',
    category: 'Umum',
    published: 1,
  });

  // Fetch all admin data when user is admin & modal is open
  const fetchAllAdminData = async (force = false) => {
    if (!isAdmin && !force) return;
    setLoadingData(true);
    try {
      const [st, sc, c, l, mhs, ann, logs] = await Promise.all([
        api.getAdminStats(),
        api.getSchedules(),
        api.getCourses(),
        api.getLecturers(),
        api.getStudents(),
        api.getAdminAnnouncements(),
        api.getAuditLogs(),
      ]);
      setStats(st);
      setSchedules(sc);
      setCourses(c);
      setLecturers(l);
      setStudents(mhs);
      setAnnouncements(ann);
      setAuditLogs(logs);
    } catch (err: any) {
      console.error('Failed to load admin data:', err);
      if (err.message && (err.message.includes('Autentikasi') || err.message.includes('Akses ditolak'))) {
        // If credentials expired or missing, clean up auth state
        await logout();
      }
    } finally {
      setLoadingData(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      if (isAdmin) {
        fetchAllAdminData();
      } else {
        setEmail('');
        setPassword('');
        setLoginError(null);
      }
    }
  }, [isOpen, isAdmin]);

  if (!isOpen) return null;

  // Handle Login
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginLoading(true);
    setLoginError(null);
    try {
      await login({ email: email.trim(), password });
      await fetchAllAdminData(true);
      if (onDataChanged) onDataChanged();
    } catch (err: any) {
      setLoginError(err.message || 'Gagal login. Periksa email dan password.');
    } finally {
      setLoginLoading(false);
    }
  };

  const showNotification = (msg: string, isErr = false) => {
    if (isErr) {
      setActionError(msg);
      setTimeout(() => setActionError(null), 4000);
    } else {
      setActionMessage(msg);
      setTimeout(() => setActionMessage(null), 4000);
    }
  };

  // ==========================================
  // COURSES HANDLERS
  // ==========================================
  const handleOpenCourseForm = (course?: Course) => {
    if (course) {
      setEditingCourse(course);
      setCourseForm({
        name: course.name,
        code: course.code,
        sks: course.sks,
        description: course.description || '',
      });
    } else {
      setEditingCourse(null);
      setCourseForm({ name: '', code: '', sks: 3, description: '' });
    }
    setIsCourseFormOpen(true);
  };

  const handleSaveCourse = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingCourse) {
        await api.updateCourse(editingCourse.id, courseForm);
        showNotification('Mata kuliah berhasil diperbarui.');
      } else {
        await api.createCourse(courseForm);
        showNotification('Mata kuliah baru berhasil ditambahkan.');
      }
      setIsCourseFormOpen(false);
      fetchAllAdminData();
      if (onDataChanged) onDataChanged();
    } catch (err: any) {
      showNotification(err.message, true);
    }
  };

  const handleDeleteCourse = async (id: string) => {
    if (!confirm('Yakin ingin menghapus mata kuliah ini? Semua jadwal terkait akan ikut terhapus.')) return;
    try {
      await api.deleteCourse(id);
      showNotification('Mata kuliah berhasil dihapus.');
      fetchAllAdminData();
      if (onDataChanged) onDataChanged();
    } catch (err: any) {
      showNotification(err.message, true);
    }
  };

  // ==========================================
  // LECTURERS HANDLERS
  // ==========================================
  const handleOpenLecturerForm = (lecturer?: Lecturer) => {
    if (lecturer) {
      setEditingLecturer(lecturer);
      setLecturerForm({
        name: lecturer.name,
        email: lecturer.email || '',
        room: lecturer.room || '',
      });
    } else {
      setEditingLecturer(null);
      setLecturerForm({ name: '', email: '', room: '' });
    }
    setIsLecturerFormOpen(true);
  };

  const handleSaveLecturer = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingLecturer) {
        await api.updateLecturer(editingLecturer.id, lecturerForm);
        showNotification('Data dosen berhasil diperbarui.');
      } else {
        await api.createLecturer(lecturerForm);
        showNotification('Dosen baru berhasil ditambahkan.');
      }
      setIsLecturerFormOpen(false);
      fetchAllAdminData();
      if (onDataChanged) onDataChanged();
    } catch (err: any) {
      showNotification(err.message, true);
    }
  };

  const handleDeleteLecturer = async (id: string) => {
    if (!confirm('Yakin ingin menghapus data dosen ini?')) return;
    try {
      await api.deleteLecturer(id);
      showNotification('Data dosen berhasil dihapus.');
      fetchAllAdminData();
      if (onDataChanged) onDataChanged();
    } catch (err: any) {
      showNotification(err.message, true);
    }
  };

  // ==========================================
  // SCHEDULES HANDLERS (WITH CONFLICT CHECK)
  // ==========================================
  const handleOpenScheduleForm = (sched?: ScheduleItem) => {
    if (sched) {
      setEditingSchedule(sched);
      setScheduleForm({
        courseId: sched.courseId,
        lecturerId: sched.lecturerId,
        dayOfWeek: sched.dayOfWeek,
        startTime: sched.startTime,
        endTime: sched.endTime,
        room: sched.room,
        recurrenceType: sched.recurrenceType || 'WEEKLY',
        specificDate: sched.specificDate || '',
      });
    } else {
      setEditingSchedule(null);
      setScheduleForm({
        courseId: courses[0]?.id || '',
        lecturerId: lecturers[0]?.id || '',
        dayOfWeek: 1,
        startTime: '08:00',
        endTime: '10:30',
        room: 'Lab Komputer 1',
        recurrenceType: 'WEEKLY',
        specificDate: '',
      });
    }
    setIsScheduleFormOpen(true);
  };

  const handleSaveSchedule = async (forceConflict = false) => {
    const payload = {
      courseId: scheduleForm.courseId,
      lecturerId: scheduleForm.lecturerId,
      dayOfWeek: Number(scheduleForm.dayOfWeek),
      startTime: scheduleForm.startTime,
      endTime: scheduleForm.endTime,
      room: scheduleForm.room,
      recurrenceType: scheduleForm.recurrenceType,
      specificDate: scheduleForm.specificDate || null,
      forceConflict,
    };

    try {
      if (editingSchedule) {
        await api.updateSchedule(editingSchedule.id, payload);
        showNotification('Jadwal berhasil diperbarui.');
      } else {
        await api.createSchedule(payload);
        showNotification('Jadwal perkuliahan baru berhasil disimpan.');
      }
      setIsScheduleFormOpen(false);
      setConflictModalData(null);
      fetchAllAdminData();
      if (onDataChanged) onDataChanged();
    } catch (err: any) {
      if (err.message && err.message.includes('bertabrakan')) {
        // Conflict occurred! Open conflict resolution modal
        setConflictModalData({
          message: err.message,
          pendingPayload: payload,
          isEditing: !!editingSchedule,
          editId: editingSchedule?.id,
        });
      } else {
        showNotification(err.message, true);
      }
    }
  };

  const handleDeleteSchedule = async (id: string) => {
    if (!confirm('Yakin ingin menghapus jadwal perkuliahan ini?')) return;
    try {
      await api.deleteSchedule(id);
      showNotification('Jadwal berhasil dihapus.');
      fetchAllAdminData();
      if (onDataChanged) onDataChanged();
    } catch (err: any) {
      showNotification(err.message, true);
    }
  };

  // ==========================================
  // STUDENTS HANDLERS
  // ==========================================
  const handleOpenStudentForm = (student: Student) => {
    setEditingStudent(student);
    setStudentForm({
      name: student.name,
      npm: student.npm,
      position: student.position,
      division: student.division,
    });
    setIsStudentFormOpen(true);
  };

  const handleSaveStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingStudent) return;
    try {
      await api.updateStudent(editingStudent.id, studentForm);
      showNotification(`Data ${studentForm.name} berhasil diperbarui.`);
      setIsStudentFormOpen(false);
      fetchAllAdminData();
      if (onDataChanged) onDataChanged();
    } catch (err: any) {
      showNotification(err.message, true);
    }
  };

  // ==========================================
  // ANNOUNCEMENTS HANDLERS
  // ==========================================
  const handleOpenAnnouncementForm = (ann?: Announcement) => {
    if (ann) {
      setEditingAnnouncement(ann);
      setAnnouncementForm({
        title: ann.title,
        content: ann.content,
        category: ann.category,
        published: ann.published ?? 1,
      });
    } else {
      setEditingAnnouncement(null);
      setAnnouncementForm({
        title: '',
        content: '',
        category: 'Umum',
        published: 1,
      });
    }
    setIsAnnouncementFormOpen(true);
  };

  const handleSaveAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingAnnouncement) {
        await api.updateAnnouncement(editingAnnouncement.id, announcementForm);
        showNotification('Pengumuman berhasil diperbarui.');
      } else {
        await api.createAnnouncement(announcementForm);
        showNotification('Pengumuman baru berhasil dipublikasikan.');
      }
      setIsAnnouncementFormOpen(false);
      fetchAllAdminData();
      if (onDataChanged) onDataChanged();
    } catch (err: any) {
      showNotification(err.message, true);
    }
  };

  const handleDeleteAnnouncement = async (id: string) => {
    if (!confirm('Hapus pengumuman ini?')) return;
    try {
      await api.deleteAnnouncement(id);
      showNotification('Pengumuman berhasil dihapus.');
      fetchAllAdminData();
      if (onDataChanged) onDataChanged();
    } catch (err: any) {
      showNotification(err.message, true);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md">
      <div className="bg-[#0b1120] border border-slate-700/80 rounded-2xl w-full max-w-5xl h-[90vh] max-h-[850px] shadow-2xl flex flex-col overflow-hidden text-slate-200">
        
        {/* Modal Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#070b14]/90 shrink-0">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-lg bg-blue-600/30 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-sm font-bold text-white font-mono">PORTAL ADMINISTRATOR TI 1C</h3>
                <span className="px-1.5 py-0.5 text-[10px] bg-slate-800 text-slate-300 font-mono rounded">
                  UNP KEDIRI
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                {isAdmin ? `Login sebagai ${user?.email}` : 'Autentikasi Hak Akses Khusus'}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            {isAdmin && (
              <button
                onClick={logout}
                className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 hover:border-rose-500/50 text-slate-300 hover:text-rose-400 text-xs font-semibold transition"
              >
                Logout
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Global Notifications inside Admin */}
        {actionMessage && (
          <div className="px-6 py-2 bg-emerald-950/80 border-b border-emerald-500/40 text-emerald-300 text-xs font-semibold flex items-center space-x-2">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{actionMessage}</span>
          </div>
        )}
        {actionError && (
          <div className="px-6 py-2 bg-rose-950/80 border-b border-rose-500/40 text-rose-300 text-xs font-semibold flex items-center space-x-2">
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{actionError}</span>
          </div>
        )}

        {/* ========================================================= */}
        {/* LOGIN FORM IF NOT AUTHENTICATED */}
        {/* ========================================================= */}
        {!isAdmin ? (
          <div className="flex-1 flex items-center justify-center p-6 overflow-y-auto">
            <div className="max-w-md w-full p-8 rounded-2xl bg-[#070b14] border border-slate-800 shadow-xl space-y-6">
              <div className="text-center space-y-2">
                <div className="w-12 h-12 rounded-xl bg-blue-950 border border-cyan-500/40 flex items-center justify-center mx-auto text-cyan-400">
                  <Lock className="w-6 h-6" />
                </div>
                <h4 className="text-lg font-bold text-white tracking-tight">Login Administrator</h4>
                <p className="text-xs text-slate-400">
                  Masukkan kredensial akun administrator untuk mengelola jadwal, kurikulum, dan data kelas.
                </p>
              </div>

              {loginError && (
                <div className="p-3 rounded-lg bg-rose-950/60 border border-rose-800 text-rose-300 text-xs flex items-center space-x-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
                  <span>{loginError}</span>
                </div>
              )}

              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-xs text-slate-300 font-medium">Username / Email Administrator</label>
                  <div className="relative">
                    <Mail className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                    <input
                      id="admin-login-username"
                      type="text"
                      required
                      placeholder="Masukkan username atau email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-slate-300 font-medium">Password</label>
                  <div className="relative">
                    <Lock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                    <input
                      id="admin-login-password"
                      type="password"
                      required
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                    />
                  </div>
                </div>

                <button
                  id="admin-submit-login-btn"
                  type="submit"
                  disabled={loginLoading}
                  className="w-full py-2.5 rounded-lg bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white text-xs font-bold tracking-wide transition shadow-lg shadow-cyan-500/20 disabled:opacity-50"
                >
                  {loginLoading ? 'Memverifikasi...' : 'Masuk ke Dashboard'}
                </button>
              </form>

              <div className="pt-2 text-center text-[11px] text-slate-500 font-mono">
                Portal Administrasi Kelas TI 1C
              </div>
            </div>
          </div>
        ) : (
          /* ========================================================= */
          /* AUTHENTICATED WORKSPACE */
          /* ========================================================= */
          <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
            
            {/* Left Workspace Navigation */}
            <div className="w-full md:w-56 bg-[#070b14] border-b md:border-b-0 md:border-r border-slate-800 p-3 space-y-1 shrink-0 overflow-x-auto md:overflow-y-auto flex md:flex-col gap-1">
              <button
                onClick={() => setActiveTab('stats')}
                className={`flex items-center space-x-2.5 w-full px-3 py-2 rounded-lg text-xs font-medium transition text-left shrink-0 ${
                  activeTab === 'stats'
                    ? 'bg-blue-600 text-white font-semibold'
                    : 'text-slate-400 hover:text-white hover:bg-slate-850'
                }`}
              >
                <Activity className="w-4 h-4 text-cyan-400" />
                <span>Statistik & Status</span>
              </button>

              <button
                onClick={() => setActiveTab('schedules')}
                className={`flex items-center space-x-2.5 w-full px-3 py-2 rounded-lg text-xs font-medium transition text-left shrink-0 ${
                  activeTab === 'schedules'
                    ? 'bg-blue-600 text-white font-semibold'
                    : 'text-slate-400 hover:text-white hover:bg-slate-850'
                }`}
              >
                <Calendar className="w-4 h-4 text-cyan-400" />
                <span>Kelola Jadwal</span>
              </button>

              <button
                onClick={() => setActiveTab('courses')}
                className={`flex items-center space-x-2.5 w-full px-3 py-2 rounded-lg text-xs font-medium transition text-left shrink-0 ${
                  activeTab === 'courses'
                    ? 'bg-blue-600 text-white font-semibold'
                    : 'text-slate-400 hover:text-white hover:bg-slate-850'
                }`}
              >
                <BookOpen className="w-4 h-4 text-cyan-400" />
                <span>Kelola Mata Kuliah</span>
              </button>

              <button
                onClick={() => setActiveTab('lecturers')}
                className={`flex items-center space-x-2.5 w-full px-3 py-2 rounded-lg text-xs font-medium transition text-left shrink-0 ${
                  activeTab === 'lecturers'
                    ? 'bg-blue-600 text-white font-semibold'
                    : 'text-slate-400 hover:text-white hover:bg-slate-850'
                }`}
              >
                <User className="w-4 h-4 text-cyan-400" />
                <span>Kelola Dosen</span>
              </button>

              <button
                onClick={() => setActiveTab('students')}
                className={`flex items-center space-x-2.5 w-full px-3 py-2 rounded-lg text-xs font-medium transition text-left shrink-0 ${
                  activeTab === 'students'
                    ? 'bg-blue-600 text-white font-semibold'
                    : 'text-slate-400 hover:text-white hover:bg-slate-850'
                }`}
              >
                <Users className="w-4 h-4 text-cyan-400" />
                <span>Struktur 35 Mhs</span>
              </button>

              <button
                onClick={() => setActiveTab('announcements')}
                className={`flex items-center space-x-2.5 w-full px-3 py-2 rounded-lg text-xs font-medium transition text-left shrink-0 ${
                  activeTab === 'announcements'
                    ? 'bg-blue-600 text-white font-semibold'
                    : 'text-slate-400 hover:text-white hover:bg-slate-850'
                }`}
              >
                <Bell className="w-4 h-4 text-cyan-400" />
                <span>Pengumuman</span>
              </button>

              <button
                onClick={() => setActiveTab('audit')}
                className={`flex items-center space-x-2.5 w-full px-3 py-2 rounded-lg text-xs font-medium transition text-left shrink-0 ${
                  activeTab === 'audit'
                    ? 'bg-blue-600 text-white font-semibold'
                    : 'text-slate-400 hover:text-white hover:bg-slate-850'
                }`}
              >
                <Shield className="w-4 h-4 text-cyan-400" />
                <span>Audit Log</span>
              </button>
            </div>

            {/* Right Main Body */}
            <div className="flex-1 p-6 overflow-y-auto bg-[#0b1120]">
              
              {/* TAB 1: STATS & SUMMARY */}
              {activeTab === 'stats' && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <h4 className="text-base font-bold text-white">Ringkasan Sistem & Statistik</h4>
                    <button
                      onClick={() => fetchAllAdminData()}
                      className="flex items-center space-x-1.5 px-3 py-1.5 rounded bg-slate-900 border border-slate-700 text-xs text-slate-300 hover:text-white"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${loadingData ? 'animate-spin' : ''}`} />
                      <span>Muat Ulang</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                    <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
                      <p className="text-xs text-slate-400">Total Mahasiswa Terdaftar</p>
                      <p className="text-2xl font-extrabold text-cyan-400 font-mono mt-1">
                        {stats?.studentsCount ?? 35}
                      </p>
                      <span className="text-[11px] text-emerald-400">Kapasitas 100% Terisi</span>
                    </div>

                    <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
                      <p className="text-xs text-slate-400">Mata Kuliah Aktif</p>
                      <p className="text-2xl font-extrabold text-blue-400 font-mono mt-1">
                        {stats?.coursesCount ?? 6}
                      </p>
                      <span className="text-[11px] text-slate-400">Semester Ganjil</span>
                    </div>

                    <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
                      <p className="text-xs text-slate-400">Dosen Pengampu</p>
                      <p className="text-2xl font-extrabold text-teal-400 font-mono mt-1">
                        {stats?.lecturersCount ?? 5}
                      </p>
                      <span className="text-[11px] text-slate-400">Terdaftar Aktif</span>
                    </div>

                    <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
                      <p className="text-xs text-slate-400">Jadwal Sesi Kuliah</p>
                      <p className="text-2xl font-extrabold text-amber-400 font-mono mt-1">
                        {stats?.schedulesCount ?? 0}
                      </p>
                      <span className="text-[11px] text-slate-400">Jadwal Mingguan</span>
                    </div>

                    <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
                      <p className="text-xs text-slate-400">Pengumuman Internal</p>
                      <p className="text-2xl font-extrabold text-indigo-400 font-mono mt-1">
                        {stats?.announcementsCount ?? 0}
                      </p>
                      <span className="text-[11px] text-slate-400">Postingan</span>
                    </div>

                    <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
                      <p className="text-xs text-slate-400">Status Keamanan</p>
                      <p className="text-2xl font-extrabold text-emerald-400 font-mono mt-1">
                        AKTIF
                      </p>
                      <span className="text-[11px] text-emerald-400">Rate Limit & CSP OK</span>
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2 text-xs text-slate-300">
                    <p className="font-bold text-white font-mono">Informasi Arsitektur Database:</p>
                    <p>• Mesin Database: SQLite (sql.js / WASM storage)</p>
                    <p>• Data tersimpan secara persisten dan terlindungi dari injeksi dengan parameterized queries.</p>
                    <p>• Deteksi tabrakan jadwal otomatis memvalidasi irisan waktu dan hari setiap penambahan/pembaruan jadwal.</p>
                  </div>
                </div>
              )}

              {/* TAB 2: SCHEDULES CRUD */}
              {activeTab === 'schedules' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <div>
                      <h4 className="text-base font-bold text-white">Kelola Jadwal Perkuliahan</h4>
                      <p className="text-xs text-slate-400">
                        Dilengkapi sistem deteksi tabrakan waktu dan ruangan otomatis.
                      </p>
                    </div>
                    <button
                      onClick={() => handleOpenScheduleForm()}
                      className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Tambah Jadwal</span>
                    </button>
                  </div>

                  <div className="space-y-2">
                    {schedules.map((s) => (
                      <div
                        key={s.id}
                        className="p-3 rounded-lg bg-slate-900/90 border border-slate-800 flex items-center justify-between text-xs"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center space-x-2">
                            <span className="px-2 py-0.5 rounded bg-blue-950 text-cyan-300 font-mono font-bold">
                              {s.dayOfWeek === 1 ? 'Senin' : s.dayOfWeek === 2 ? 'Selasa' : s.dayOfWeek === 3 ? 'Rabu' : s.dayOfWeek === 4 ? 'Kamis' : 'Jumat'}
                            </span>
                            <span className="font-mono text-slate-300">{s.startTime} - {s.endTime}</span>
                            <span className="text-slate-400 font-mono">• {s.room}</span>
                          </div>
                          <p className="font-bold text-white text-sm">{s.courseName}</p>
                          <p className="text-slate-400 text-[11px]">{s.lecturerName}</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => handleOpenScheduleForm(s)}
                            className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteSchedule(s.id)}
                            className="p-1.5 rounded bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-400"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 3: COURSES CRUD */}
              {activeTab === 'courses' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <h4 className="text-base font-bold text-white">Kelola Mata Kuliah</h4>
                    <button
                      onClick={() => handleOpenCourseForm()}
                      className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Tambah Mata Kuliah</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {courses.map((c) => (
                      <div
                        key={c.id}
                        className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 space-y-2 flex flex-col justify-between"
                      >
                        <div>
                          <div className="flex items-center justify-between">
                            <span className="px-2 py-0.5 rounded bg-blue-950 text-cyan-300 font-mono text-[11px] font-bold">
                              {c.code}
                            </span>
                            <span className="text-xs text-slate-400 font-mono">{c.sks} SKS</span>
                          </div>
                          <h5 className="font-bold text-white text-sm mt-1">{c.name}</h5>
                          {c.description && (
                            <p className="text-xs text-slate-400 mt-1 line-clamp-2">{c.description}</p>
                          )}
                        </div>
                        <div className="pt-2 border-t border-slate-800 flex justify-end space-x-2">
                          <button
                            onClick={() => handleOpenCourseForm(c)}
                            className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center space-x-1"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                            <span>Ubah</span>
                          </button>
                          <button
                            onClick={() => handleDeleteCourse(c.id)}
                            className="p-1.5 rounded bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-400 text-xs flex items-center space-x-1"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Hapus</span>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 4: LECTURERS CRUD */}
              {activeTab === 'lecturers' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <h4 className="text-base font-bold text-white">Kelola Data Dosen</h4>
                    <button
                      onClick={() => handleOpenLecturerForm()}
                      className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Tambah Dosen</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {lecturers.map((l) => (
                      <div
                        key={l.id}
                        className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between"
                      >
                        <div className="space-y-1">
                          <h5 className="font-bold text-white text-sm">{l.name}</h5>
                          <p className="text-xs text-slate-400">{l.room || 'Ruang Dosen'}</p>
                          {l.email && <p className="text-[11px] text-cyan-400 font-mono">{l.email}</p>}
                        </div>
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => handleOpenLecturerForm(l)}
                            className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteLecturer(l.id)}
                            className="p-1.5 rounded bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-400"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 5: STUDENTS (STRUKTUR 35 MAHASISWA) */}
              {activeTab === 'students' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <div>
                      <h4 className="text-base font-bold text-white">Data 35 Mahasiswa Kelas TI 1C</h4>
                      <p className="text-xs text-slate-400">
                        Edit data nama, NPM, jabatan organisasi, dan divisi mahasiswa.
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {students.map((s) => (
                      <div
                        key={s.id}
                        className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-2 flex flex-col justify-between"
                      >
                        <div>
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-white text-xs">{s.name}</span>
                            <span className="text-[10px] font-mono text-cyan-400">{s.npm}</span>
                          </div>
                          <div className="text-[11px] text-slate-400 mt-1">
                            <p className="text-slate-300 font-semibold">{s.position}</p>
                            <p>{s.division}</p>
                          </div>
                        </div>
                        <div className="pt-2 border-t border-slate-800 flex justify-end">
                          <button
                            onClick={() => handleOpenStudentForm(s)}
                            className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded text-xs flex items-center space-x-1"
                          >
                            <Edit2 className="w-3 h-3" />
                            <span>Edit Mahasiswa</span>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 6: ANNOUNCEMENTS CRUD */}
              {activeTab === 'announcements' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <h4 className="text-base font-bold text-white">Kelola Pengumuman Kelas</h4>
                    <button
                      onClick={() => handleOpenAnnouncementForm()}
                      className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Buat Pengumuman</span>
                    </button>
                  </div>

                  <div className="space-y-2">
                    {announcements.map((a) => (
                      <div
                        key={a.id}
                        className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 flex items-start justify-between gap-4"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center space-x-2">
                            <span className="px-2 py-0.5 rounded bg-blue-950 text-cyan-300 font-mono text-[10px] font-bold uppercase">
                              {a.category}
                            </span>
                            <span className="text-xs text-slate-500 font-mono">
                              {new Date(a.createdAt).toLocaleDateString('id-ID')}
                            </span>
                            {a.published === 0 && (
                              <span className="px-1.5 py-0.5 bg-amber-950 text-amber-400 text-[10px] rounded">
                                Draft
                              </span>
                            )}
                          </div>
                          <h5 className="font-bold text-white text-sm">{a.title}</h5>
                          <p className="text-xs text-slate-400 line-clamp-2">{a.content}</p>
                        </div>
                        <div className="flex items-center space-x-2 shrink-0">
                          <button
                            onClick={() => handleOpenAnnouncementForm(a)}
                            className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteAnnouncement(a.id)}
                            className="p-1.5 rounded bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-400"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 7: AUDIT LOGS */}
              {activeTab === 'audit' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <div>
                      <h4 className="text-base font-bold text-white">Log Audit Keamanan & Aktivitas</h4>
                      <p className="text-xs text-slate-400">
                        Catatan riwayat tindakan administrator untuk akuntabilitas sistem.
                      </p>
                    </div>
                  </div>

                  <div className="space-y-2 font-mono text-xs">
                    {auditLogs.length === 0 ? (
                      <p className="text-slate-400 text-center py-6">Belum ada riwayat audit.</p>
                    ) : (
                      auditLogs.map((log) => (
                        <div
                          key={log.id}
                          className="p-2.5 rounded bg-slate-900/90 border border-slate-800 flex items-center justify-between gap-2"
                        >
                          <div className="space-y-0.5">
                            <div className="flex items-center space-x-2">
                              <span className="px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-400 font-bold text-[10px]">
                                {log.action}
                              </span>
                              <span className="text-slate-300">{log.userEmail}</span>
                            </div>
                            {log.details && (
                              <p className="text-[11px] text-slate-400 font-sans">{log.details}</p>
                            )}
                          </div>
                          <span className="text-[10px] text-slate-500 whitespace-nowrap">
                            {new Date(log.createdAt).toLocaleString('id-ID')}
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}

            </div>
          </div>
        )}

      </div>

      {/* ========================================================= */}
      {/* SUB-MODAL: COURSE FORM */}
      {/* ========================================================= */}
      {isCourseFormOpen && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80">
          <div className="bg-[#0b1120] border border-slate-700 rounded-xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <h4 className="text-base font-bold text-white">
              {editingCourse ? 'Ubah Mata Kuliah' : 'Tambah Mata Kuliah Baru'}
            </h4>
            <form onSubmit={handleSaveCourse} className="space-y-3">
              <div>
                <label className="text-xs text-slate-300 font-medium">Nama Mata Kuliah</label>
                <input
                  type="text"
                  required
                  placeholder="contoh: Algoritma & Pemrograman"
                  value={courseForm.name}
                  onChange={(e) => setCourseForm({ ...courseForm, name: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-xs text-white"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs text-slate-300 font-medium">Kode Mata Kuliah</label>
                  <input
                    type="text"
                    required
                    placeholder="contoh: TI-101"
                    value={courseForm.code}
                    onChange={(e) => setCourseForm({ ...courseForm, code: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-300 font-medium">Jumlah SKS</label>
                  <input
                    type="number"
                    min={1}
                    max={6}
                    required
                    value={courseForm.sks}
                    onChange={(e) => setCourseForm({ ...courseForm, sks: parseInt(e.target.value, 10) || 1 })}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-xs text-white"
                  />
                </div>
              </div>
              <div>
                <label className="text-xs text-slate-300 font-medium">Deskripsi Singkat</label>
                <textarea
                  rows={3}
                  value={courseForm.description}
                  onChange={(e) => setCourseForm({ ...courseForm, description: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-xs text-white"
                />
              </div>
              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsCourseFormOpen(false)}
                  className="px-3 py-1.5 rounded bg-slate-800 text-slate-300 text-xs"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded bg-blue-600 text-white font-semibold text-xs"
                >
                  Simpan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SUB-MODAL: LECTURER FORM */}
      {/* ========================================================= */}
      {isLecturerFormOpen && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80">
          <div className="bg-[#0b1120] border border-slate-700 rounded-xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <h4 className="text-base font-bold text-white">
              {editingLecturer ? 'Ubah Data Dosen' : 'Tambah Dosen Baru'}
            </h4>
            <form onSubmit={handleSaveLecturer} className="space-y-3">
              <div>
                <label className="text-xs text-slate-300 font-medium">Nama Lengkap & Gelar</label>
                <input
                  type="text"
                  required
                  placeholder="contoh: Dosen Demo 01, M.Kom."
                  value={lecturerForm.name}
                  onChange={(e) => setLecturerForm({ ...lecturerForm, name: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-xs text-white"
                />
              </div>
              <div>
                <label className="text-xs text-slate-300 font-medium">Email Akademik</label>
                <input
                  type="email"
                  placeholder="contoh: dosen@unpkediri.ac.id"
                  value={lecturerForm.email}
                  onChange={(e) => setLecturerForm({ ...lecturerForm, email: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-xs text-white"
                />
              </div>
              <div>
                <label className="text-xs text-slate-300 font-medium">Ruangan Dosen / Kantor</label>
                <input
                  type="text"
                  placeholder="contoh: Ruang Dosen Gedung D"
                  value={lecturerForm.room}
                  onChange={(e) => setLecturerForm({ ...lecturerForm, room: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-xs text-white"
                />
              </div>
              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsLecturerFormOpen(false)}
                  className="px-3 py-1.5 rounded bg-slate-800 text-slate-300 text-xs"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded bg-blue-600 text-white font-semibold text-xs"
                >
                  Simpan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SUB-MODAL: SCHEDULE FORM */}
      {/* ========================================================= */}
      {isScheduleFormOpen && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80">
          <div className="bg-[#0b1120] border border-slate-700 rounded-xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <h4 className="text-base font-bold text-white">
              {editingSchedule ? 'Ubah Jadwal Perkuliahan' : 'Tambah Jadwal Baru'}
            </h4>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-300 font-medium">Mata Kuliah</label>
                <select
                  value={scheduleForm.courseId}
                  onChange={(e) => setScheduleForm({ ...scheduleForm, courseId: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-xs text-white"
                >
                  {courses.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.code})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs text-slate-300 font-medium">Dosen Pengampu</label>
                <select
                  value={scheduleForm.lecturerId}
                  onChange={(e) => setScheduleForm({ ...scheduleForm, lecturerId: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-xs text-white"
                >
                  {lecturers.map((l) => (
                    <option key={l.id} value={l.id}>
                      {l.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs text-slate-300 font-medium">Hari</label>
                  <select
                    value={scheduleForm.dayOfWeek}
                    onChange={(e) => setScheduleForm({ ...scheduleForm, dayOfWeek: parseInt(e.target.value, 10) })}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-xs text-white"
                  >
                    <option value={1}>Senin</option>
                    <option value={2}>Selasa</option>
                    <option value={3}>Rabu</option>
                    <option value={4}>Kamis</option>
                    <option value={5}>Jumat</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs text-slate-300 font-medium">Ruangan / Lab</label>
                  <input
                    type="text"
                    required
                    placeholder="contoh: Lab Komputer 1"
                    value={scheduleForm.room}
                    onChange={(e) => setScheduleForm({ ...scheduleForm, room: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs text-slate-300 font-medium">Jam Mulai (HH:mm)</label>
                  <input
                    type="time"
                    required
                    value={scheduleForm.startTime}
                    onChange={(e) => setScheduleForm({ ...scheduleForm, startTime: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-300 font-medium">Jam Selesai (HH:mm)</label>
                  <input
                    type="time"
                    required
                    value={scheduleForm.endTime}
                    onChange={(e) => setScheduleForm({ ...scheduleForm, endTime: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-xs text-white"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsScheduleFormOpen(false)}
                  className="px-3 py-1.5 rounded bg-slate-800 text-slate-300 text-xs"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={() => handleSaveSchedule(false)}
                  className="px-4 py-1.5 rounded bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs"
                >
                  Simpan Jadwal
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* CONFLICT WARNING DIALOG */}
      {/* ========================================================= */}
      {conflictModalData && (
        <div className="fixed inset-0 z-70 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
          <div className="bg-[#0b1120] border border-amber-500/80 rounded-xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center space-x-2 text-amber-400">
              <AlertTriangle className="w-5 h-5" />
              <h4 className="text-base font-bold text-white">Konflik Jadwal Dideteksi</h4>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              {conflictModalData.message}
            </p>
            <div className="pt-2 flex justify-end space-x-2">
              <button
                onClick={() => setConflictModalData(null)}
                className="px-3 py-1.5 rounded bg-slate-800 text-slate-300 text-xs"
              >
                Kembali & Perbaiki
              </button>
              <button
                onClick={() => handleSaveSchedule(true)}
                className="px-3 py-1.5 rounded bg-amber-600 hover:bg-amber-500 text-white font-semibold text-xs"
              >
                Tetap Simpan (Abaikan Konflik)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SUB-MODAL: STUDENT FORM */}
      {/* ========================================================= */}
      {isStudentFormOpen && editingStudent && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80">
          <div className="bg-[#0b1120] border border-slate-700 rounded-xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <h4 className="text-base font-bold text-white">
              Edit Mahasiswa #{editingStudent.orderIndex}
            </h4>
            <form onSubmit={handleSaveStudent} className="space-y-3">
              <div>
                <label className="text-xs text-slate-300 font-medium">Nama Mahasiswa</label>
                <input
                  type="text"
                  required
                  value={studentForm.name}
                  onChange={(e) => setStudentForm({ ...studentForm, name: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-xs text-white"
                />
              </div>
              <div>
                <label className="text-xs text-slate-300 font-medium">NPM</label>
                <input
                  type="text"
                  required
                  value={studentForm.npm}
                  onChange={(e) => setStudentForm({ ...studentForm, npm: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-xs text-white font-mono"
                />
              </div>
              <div>
                <label className="text-xs text-slate-300 font-medium">Jabatan / Role</label>
                <input
                  type="text"
                  required
                  value={studentForm.position}
                  onChange={(e) => setStudentForm({ ...studentForm, position: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-xs text-white"
                />
              </div>
              <div>
                <label className="text-xs text-slate-300 font-medium">Divisi</label>
                <input
                  type="text"
                  required
                  value={studentForm.division}
                  onChange={(e) => setStudentForm({ ...studentForm, division: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-xs text-white"
                />
              </div>
              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsStudentFormOpen(false)}
                  className="px-3 py-1.5 rounded bg-slate-800 text-slate-300 text-xs"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded bg-blue-600 text-white font-semibold text-xs"
                >
                  Simpan Perubahan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SUB-MODAL: ANNOUNCEMENT FORM */}
      {/* ========================================================= */}
      {isAnnouncementFormOpen && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80">
          <div className="bg-[#0b1120] border border-slate-700 rounded-xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <h4 className="text-base font-bold text-white">
              {editingAnnouncement ? 'Ubah Pengumuman' : 'Buat Pengumuman Baru'}
            </h4>
            <form onSubmit={handleSaveAnnouncement} className="space-y-3">
              <div>
                <label className="text-xs text-slate-300 font-medium">Judul Pengumuman</label>
                <input
                  type="text"
                  required
                  value={announcementForm.title}
                  onChange={(e) => setAnnouncementForm({ ...announcementForm, title: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-xs text-white"
                />
              </div>
              <div>
                <label className="text-xs text-slate-300 font-medium">Kategori</label>
                <select
                  value={announcementForm.category}
                  onChange={(e) => setAnnouncementForm({ ...announcementForm, category: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-xs text-white"
                >
                  <option value="Umum">Umum</option>
                  <option value="Akademik">Akademik</option>
                  <option value="Tugas">Tugas</option>
                </select>
              </div>
              <div>
                <label className="text-xs text-slate-300 font-medium">Isi Pengumuman</label>
                <textarea
                  rows={4}
                  required
                  value={announcementForm.content}
                  onChange={(e) => setAnnouncementForm({ ...announcementForm, content: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-xs text-white"
                />
              </div>
              <div>
                <label className="text-xs text-slate-300 font-medium">Status Publikasi</label>
                <select
                  value={announcementForm.published}
                  onChange={(e) => setAnnouncementForm({ ...announcementForm, published: parseInt(e.target.value, 10) })}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-xs text-white"
                >
                  <option value={1}>Publikasikan Sekarang</option>
                  <option value={0}>Simpan sebagai Draft</option>
                </select>
              </div>
              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsAnnouncementFormOpen(false)}
                  className="px-3 py-1.5 rounded bg-slate-800 text-slate-300 text-xs"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded bg-blue-600 text-white font-semibold text-xs"
                >
                  Simpan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
