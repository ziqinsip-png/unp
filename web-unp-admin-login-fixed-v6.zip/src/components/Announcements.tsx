import React, { useState, useEffect } from 'react';
import { Bell, Calendar, Tag, ChevronRight, X, Sparkles, CheckCircle2 } from 'lucide-react';
import { Announcement } from '../types.ts';
import { api } from '../services/api.ts';

export const Announcements: React.FC = () => {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedCategory, setSelectedCategory] = useState<string>('Semua');
  const [activeModalItem, setActiveModalItem] = useState<Announcement | null>(null);

  const loadData = async () => {
    setLoading(true);
    try {
      const data = await api.getAnnouncements();
      setAnnouncements(data);
    } catch (err) {
      console.error('Failed to load announcements:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const categories = ['Semua', 'Umum', 'Akademik', 'Tugas'];

  const filtered = announcements.filter(
    (a) => selectedCategory === 'Semua' || a.category === selectedCategory
  );

  const formatDate = (isoStr: string) => {
    try {
      const date = new Date(isoStr);
      return date.toLocaleDateString('id-ID', {
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      });
    } catch {
      return isoStr;
    }
  };

  return (
    <section id="pengumuman" className="py-16 border-b border-slate-800/80 bg-[#070b14]/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <div className="inline-flex items-center space-x-2 px-2.5 py-1 rounded bg-blue-950/80 border border-blue-500/40 text-blue-400 text-xs font-mono mb-2">
              <Bell className="w-3.5 h-3.5 text-cyan-400" />
              <span>PAPAN INFORMASI INTERNAL</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Pengumuman & Pemberitahuan Kelas
            </h2>
            <p className="text-sm text-slate-400 mt-1">
              Informasi terkini kegiatan akademik, tugas kelompok, dan surat edaran perkuliahan TI 1C.
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex items-center gap-1.5 bg-slate-900 p-1.5 rounded-lg border border-slate-800">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-md text-xs font-medium transition ${
                  selectedCategory === cat
                    ? 'bg-blue-600 text-white font-semibold'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        {loading ? (
          <div className="p-16 text-center text-xs text-slate-400">Memuat pengumuman kelas...</div>
        ) : filtered.length === 0 ? (
          <div className="p-12 text-center rounded-xl bg-slate-900/40 border border-slate-800 text-slate-400 text-xs">
            Belum ada pengumuman untuk kategori yang dipilih.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filtered.map((item) => (
              <div
                key={item.id}
                onClick={() => setActiveModalItem(item)}
                className="p-5 rounded-xl bg-[#0b1120] border border-slate-800 hover:border-cyan-500/40 transition-all cursor-pointer flex flex-col justify-between space-y-4 group"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono uppercase ${
                        item.category === 'Akademik'
                          ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/40'
                          : item.category === 'Tugas'
                          ? 'bg-amber-950 text-amber-300 border border-amber-500/40'
                          : 'bg-blue-950 text-blue-300 border border-blue-500/40'
                      }`}
                    >
                      {item.category}
                    </span>
                    <span className="text-[11px] text-slate-500 font-mono">
                      {formatDate(item.createdAt)}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-white group-hover:text-cyan-300 transition-colors line-clamp-2">
                    {item.title}
                  </h3>

                  <p className="text-xs text-slate-400 mt-2 line-clamp-3 leading-relaxed">
                    {item.content}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-cyan-400 font-semibold">
                  <span>Baca Selengkapnya</span>
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            ))}
          </div>
        )}

      </div>

      {/* Detail Modal */}
      {activeModalItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#0b1120] border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 animate-in fade-in duration-150">
            <div className="flex items-start justify-between pb-3 border-b border-slate-800">
              <div className="space-y-1">
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-950 text-cyan-300 border border-cyan-500/30">
                  {activeModalItem.category}
                </span>
                <span className="text-xs text-slate-400 font-mono ml-2">
                  {formatDate(activeModalItem.createdAt)}
                </span>
              </div>
              <button
                onClick={() => setActiveModalItem(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <h3 className="text-lg font-bold text-white leading-snug">
              {activeModalItem.title}
            </h3>

            <div className="text-xs sm:text-sm text-slate-300 leading-relaxed max-h-80 overflow-y-auto pr-2 space-y-3 whitespace-pre-line">
              {activeModalItem.content}
            </div>

            <div className="pt-3 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setActiveModalItem(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-lg transition"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
