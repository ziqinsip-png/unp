import React from 'react';
import { ShieldCheck, Terminal, MapPin, Globe, ExternalLink, Heart } from 'lucide-react';

interface FooterProps {
  onOpenAdmin: () => void;
  onNavigate: (id: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenAdmin, onNavigate }) => {
  return (
    <footer className="bg-[#050811] border-t border-slate-800/80 text-slate-400 text-xs relative overflow-hidden">
      {/* Accent glow line */}
      <div className="h-[2px] w-full bg-gradient-to-r from-transparent via-cyan-500/60 to-transparent" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
          
          {/* Col 1: Class Branding & Identity */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-9 h-9 rounded-lg bg-blue-600/30 border border-cyan-500/40 flex items-center justify-center text-cyan-400 font-mono font-bold">
                1C
              </div>
              <div>
                <h4 className="text-white font-extrabold text-sm tracking-tight font-mono">
                  TEKNIK INFORMATIKA 1C
                </h4>
                <p className="text-[11px] text-slate-400 font-mono">
                  UNIVERSITAS NUSANTARA PGRI KEDIRI
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              Sistem informasi akademik internal terpadu kelas Teknik Informatika 1C angkatan 2026. Menghubungkan 35 mahasiswa, jadwal perkuliahan harian, dan pengumuman resmi.
            </p>

            <div className="inline-flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-[11px] font-mono text-cyan-400">
              <span>#</span>
              <span className="text-white font-semibold">35 MAHASISWA • 1 KELAS • 1 CERITA</span>
            </div>
          </div>

          {/* Col 2: Navigasi Cepat */}
          <div className="md:col-span-3 space-y-3">
            <h5 className="text-white font-bold text-xs font-mono uppercase tracking-wider">
              Navigasi Cepat
            </h5>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => onNavigate('beranda')}
                  className="hover:text-cyan-400 transition"
                >
                  Beranda Kelas
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('besok')}
                  className="hover:text-cyan-400 transition"
                >
                  Besok Kuliah Apa?
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('jadwal')}
                  className="hover:text-cyan-400 transition"
                >
                  Jadwal & Kalender Akademik
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('struktur')}
                  className="hover:text-cyan-400 transition"
                >
                  Struktur 35 Mahasiswa
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('akademik')}
                  className="hover:text-cyan-400 transition"
                >
                  Mata Kuliah & Dosen
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('pengumuman')}
                  className="hover:text-cyan-400 transition"
                >
                  Pengumuman Kelas
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Keamanan & Info Kampus */}
          <div className="md:col-span-4 space-y-3">
            <h5 className="text-white font-bold text-xs font-mono uppercase tracking-wider">
              Keamanan & Standar Sistem
            </h5>
            
            <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2 text-[11px]">
              <div className="flex items-center space-x-2 text-emerald-400 font-semibold">
                <ShieldCheck className="w-4 h-4" />
                <span>Security Posture Verified</span>
              </div>
              <p className="text-slate-400 leading-snug">
                Dilengkapi enkripsi password bcryptjs, sesi HttpOnly cookie, pencegahan tabrakan jadwal, parameterized queries SQLite, dan proteksi header Helmet.
              </p>
            </div>

            <div className="pt-1">
              <button
                onClick={onOpenAdmin}
                className="inline-flex items-center space-x-2 text-xs text-cyan-400 hover:text-cyan-300 font-medium font-mono"
              >
                <span>Portal Pengurus / Admin Kelas</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 gap-3">
          <p>© {new Date().getFullYear()} Teknik Informatika 1C — Universitas Nusantara PGRI Kediri.</p>
          <div className="flex items-center space-x-4">
            <span>Kampus 1: Jl. KH. Achmad Dahlan No. 76, Kediri</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
