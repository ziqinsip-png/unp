import React, { useState, useEffect } from 'react';
import { BookOpen, User, MapPin, Mail, Layers, Award, CheckCircle2 } from 'lucide-react';
import { Course, Lecturer } from '../types.ts';
import { api } from '../services/api.ts';

export const CoursesAndLecturers: React.FC = () => {
  const [tab, setTab] = useState<'courses' | 'lecturers'>('courses');
  const [courses, setCourses] = useState<Course[]>([]);
  const [lecturers, setLecturers] = useState<Lecturer[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [cData, lData] = await Promise.all([api.getCourses(), api.getLecturers()]);
        setCourses(cData);
        setLecturers(lData);
      } catch (err) {
        console.error('Failed to load courses/lecturers:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const totalSks = courses.reduce((acc, c) => acc + (c.sks || 0), 0);

  return (
    <section id="akademik" className="py-16 border-b border-slate-800/80 bg-[#070b14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <div className="inline-flex items-center space-x-2 px-2.5 py-1 rounded bg-blue-950/80 border border-blue-500/40 text-blue-400 text-xs font-mono mb-2">
              <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
              <span>KURIKULUM & TENAGA PENGAJAR</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Mata Kuliah & Dosen Pengampu
            </h2>
            <p className="text-sm text-slate-400 mt-1">
              Daftar mata kuliah aktif semester ganjil dan profil dosen pengajar Program Studi Teknik Informatika.
            </p>
          </div>

          {/* Subtabs */}
          <div className="flex items-center bg-slate-900 p-1 rounded-lg border border-slate-800">
            <button
              onClick={() => setTab('courses')}
              className={`flex items-center space-x-2 px-3 py-1.5 rounded-md text-xs font-semibold transition ${
                tab === 'courses'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>Mata Kuliah ({courses.length})</span>
            </button>
            <button
              onClick={() => setTab('lecturers')}
              className={`flex items-center space-x-2 px-3 py-1.5 rounded-md text-xs font-semibold transition ${
                tab === 'lecturers'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <User className="w-4 h-4" />
              <span>Dosen Pengampu ({lecturers.length})</span>
            </button>
          </div>
        </div>

        {loading ? (
          <div className="p-16 text-center text-xs text-slate-400">Memuat data kurikulum dan dosen...</div>
        ) : tab === 'courses' ? (
          /* ========================================================= */
          /* COURSES GRID */
          /* ========================================================= */
          <div className="space-y-6">
            {/* Meta bar */}
            <div className="flex items-center justify-between p-3.5 rounded-xl bg-[#0b1120] border border-slate-800 text-xs">
              <span className="text-slate-300 font-medium">
                Total Beban Studi Semester Ganjil:
              </span>
              <div className="flex items-center space-x-2">
                <span className="px-2.5 py-1 rounded bg-blue-950 text-cyan-300 border border-cyan-500/40 font-mono font-bold">
                  {totalSks} SKS Total
                </span>
                <span className="px-2.5 py-1 rounded bg-slate-800 text-slate-300 font-mono">
                  {courses.length} Mata Kuliah
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {courses.map((course) => (
                <div
                  key={course.id}
                  className="p-5 rounded-xl bg-[#0b1120] border border-slate-800 hover:border-cyan-500/40 transition-all flex flex-col justify-between space-y-4 relative group"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="px-2 py-0.5 rounded bg-blue-950/80 border border-blue-500/30 text-cyan-300 font-mono text-xs font-bold">
                        {course.code}
                      </span>
                      <span className="px-2 py-0.5 rounded bg-slate-800 text-xs font-mono font-bold text-slate-300 border border-slate-700">
                        {course.sks} SKS
                      </span>
                    </div>

                    <h3 className="text-base font-bold text-white group-hover:text-cyan-300 transition-colors">
                      {course.name}
                    </h3>

                    {course.description && (
                      <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                        {course.description}
                      </p>
                    )}
                  </div>

                  <div className="pt-3 border-t border-slate-800/80 space-y-1 text-xs">
                    <span className="text-[10px] text-slate-500 uppercase tracking-wider font-mono">
                      Dosen Pengampu:
                    </span>
                    <p className="text-slate-200 font-medium flex items-center space-x-1.5">
                      <User className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                      <span>{course.lecturerNames || 'Dosen Pengampu Terjadwal'}</span>
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          /* ========================================================= */
          /* LECTURERS GRID */
          /* ========================================================= */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {lecturers.map((lecturer) => (
              <div
                key={lecturer.id}
                className="p-5 rounded-xl bg-[#0b1120] border border-slate-800 hover:border-cyan-500/40 transition-all flex flex-col justify-between space-y-4"
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-900/60 to-cyan-900/30 border border-cyan-500/30 flex items-center justify-center mb-3 text-cyan-400">
                    <User className="w-6 h-6" />
                  </div>

                  <h3 className="text-base font-bold text-white">{lecturer.name}</h3>
                  <span className="text-[11px] text-slate-400 font-mono mt-0.5 block">
                    Dosen Teknik Informatika
                  </span>

                  {lecturer.courseNames && (
                    <div className="mt-3 p-2.5 rounded-lg bg-slate-900/80 border border-slate-800 space-y-1">
                      <span className="text-[10px] text-slate-400 uppercase font-mono block">
                        Mengampu Mata Kuliah:
                      </span>
                      <p className="text-xs text-cyan-300 font-medium">
                        {lecturer.courseNames}
                      </p>
                    </div>
                  )}
                </div>

                <div className="pt-3 border-t border-slate-800/80 space-y-2 text-xs text-slate-300 font-mono">
                  {lecturer.room && (
                    <div className="flex items-center space-x-2">
                      <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span className="text-slate-200">{lecturer.room}</span>
                    </div>
                  )}
                  {lecturer.email && (
                    <div className="flex items-center space-x-2">
                      <Mail className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                      <span className="text-slate-400 hover:text-cyan-300 transition truncate">
                        {lecturer.email}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

      </div>
    </section>
  );
};
