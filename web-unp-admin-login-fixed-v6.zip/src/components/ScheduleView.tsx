import React, { useState, useEffect } from 'react';
import { Calendar as CalendarIcon, Clock, MapPin, User, Search, Filter, ChevronLeft, ChevronRight, Grid, List, CheckCircle } from 'lucide-react';
import { CalendarDay, CalendarResponse, ScheduleItem } from '../types.ts';
import { api } from '../services/api.ts';

const DAY_NAMES = ['', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];
const MONTH_NAMES = [
  '', 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
  'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
];

export const ScheduleView: React.FC = () => {
  const [viewMode, setViewMode] = useState<'weekly' | 'calendar'>('weekly');
  const [schedules, setSchedules] = useState<ScheduleItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Filters for weekly view
  const [selectedDay, setSelectedDay] = useState<number | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Calendar state
  const [currentYear, setCurrentYear] = useState<number>(new Date().getFullYear());
  const [currentMonth, setCurrentMonth] = useState<number>(new Date().getMonth() + 1);
  const [calendarData, setCalendarData] = useState<CalendarResponse | null>(null);
  const [selectedCalendarDay, setSelectedCalendarDay] = useState<CalendarDay | null>(null);
  const [calendarLoading, setCalendarLoading] = useState<boolean>(false);

  // Load weekly schedules
  const loadSchedules = async () => {
    setLoading(true);
    try {
      const data = await api.getSchedules();
      setSchedules(data);
    } catch (err: any) {
      setError(err.message || 'Gagal memuat jadwal.');
    } finally {
      setLoading(false);
    }
  };

  // Load calendar
  const loadCalendar = async (year: number, month: number) => {
    setCalendarLoading(true);
    try {
      const data = await api.getCalendar(year, month);
      setCalendarData(data);
      // Auto select today or first day with classes
      const todayStr = new Date().toISOString().split('T')[0];
      const matchToday = data.days.find((d) => d.date === todayStr);
      if (matchToday) {
        setSelectedCalendarDay(matchToday);
      } else {
        const firstWithClass = data.days.find((d) => d.hasClasses);
        setSelectedCalendarDay(firstWithClass || data.days[0] || null);
      }
    } catch (err: any) {
      console.error('Calendar load error:', err);
    } finally {
      setCalendarLoading(false);
    }
  };

  useEffect(() => {
    loadSchedules();
  }, []);

  useEffect(() => {
    if (viewMode === 'calendar') {
      loadCalendar(currentYear, currentMonth);
    }
  }, [viewMode, currentYear, currentMonth]);

  const handlePrevMonth = () => {
    if (currentMonth === 1) {
      setCurrentMonth(12);
      setCurrentYear(currentYear - 1);
    } else {
      setCurrentMonth(currentMonth - 1);
    }
  };

  const handleNextMonth = () => {
    if (currentMonth === 12) {
      setCurrentMonth(1);
      setCurrentYear(currentYear + 1);
    } else {
      setCurrentMonth(currentMonth + 1);
    }
  };

  const handleCurrentMonth = () => {
    const now = new Date();
    setCurrentYear(now.getFullYear());
    setCurrentMonth(now.getMonth() + 1);
  };

  // Filtered schedules for weekly view
  const filteredSchedules = schedules.filter((item) => {
    const matchDay = selectedDay === 'all' || item.dayOfWeek === selectedDay;
    const matchSearch =
      searchQuery === '' ||
      item.courseName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.courseCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.lecturerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.room.toLowerCase().includes(searchQuery.toLowerCase());
    return matchDay && matchSearch;
  });

  // Group schedules by day for weekly view
  const daysWithSchedules = [1, 2, 3, 4, 5].map((dayNum) => {
    return {
      dayNum,
      dayName: DAY_NAMES[dayNum],
      items: filteredSchedules.filter((s) => s.dayOfWeek === dayNum),
    };
  }).filter((group) => selectedDay === 'all' || group.dayNum === selectedDay);

  return (
    <section id="jadwal" className="py-16 border-b border-slate-800/80 bg-[#070b14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <div className="inline-flex items-center space-x-2 px-2.5 py-1 rounded bg-blue-950/80 border border-blue-500/40 text-blue-400 text-xs font-mono mb-2">
              <CalendarIcon className="w-3.5 h-3.5 text-cyan-400" />
              <span>SISTEM AKADEMIK KELAS 1C</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Jadwal Kuliah & Kalender Akademik
            </h2>
            <p className="text-sm text-slate-400 mt-1">
              Informasi perkuliahan mingguan dan monitoring kalender semester ganjil UNP Kediri.
            </p>
          </div>

          {/* Toggle View: Weekly vs Calendar */}
          <div className="flex items-center bg-slate-900 p-1 rounded-lg border border-slate-800 shrink-0">
            <button
              onClick={() => setViewMode('weekly')}
              className={`flex items-center space-x-2 px-3 py-1.5 rounded-md text-xs font-semibold transition ${
                viewMode === 'weekly'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <List className="w-4 h-4" />
              <span>Jadwal Mingguan</span>
            </button>
            <button
              onClick={() => setViewMode('calendar')}
              className={`flex items-center space-x-2 px-3 py-1.5 rounded-md text-xs font-semibold transition ${
                viewMode === 'calendar'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Grid className="w-4 h-4" />
              <span>Kalender Bulanan</span>
            </button>
          </div>
        </div>

        {/* ========================================================= */}
        {/* VIEW 1: WEEKLY SCHEDULE VIEW */}
        {/* ========================================================= */}
        {viewMode === 'weekly' && (
          <div className="space-y-6">
            {/* Filter Bar */}
            <div className="flex flex-col sm:flex-row gap-3 items-center justify-between bg-[#0b1120] p-3.5 rounded-xl border border-slate-800">
              {/* Day Filter Pills */}
              <div className="flex flex-wrap items-center gap-1.5 w-full sm:w-auto">
                <button
                  onClick={() => setSelectedDay('all')}
                  className={`px-3 py-1.5 rounded-md text-xs font-medium transition ${
                    selectedDay === 'all'
                      ? 'bg-cyan-950 text-cyan-400 border border-cyan-500/40 font-semibold'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  Semua Hari
                </button>
                {[1, 2, 3, 4, 5].map((d) => (
                  <button
                    key={d}
                    onClick={() => setSelectedDay(d)}
                    className={`px-2.5 py-1.5 rounded-md text-xs font-medium transition ${
                      selectedDay === d
                        ? 'bg-blue-600 text-white font-semibold'
                        : 'text-slate-400 hover:text-white hover:bg-slate-800'
                    }`}
                  >
                    {DAY_NAMES[d]}
                  </button>
                ))}
              </div>

              {/* Search Bar */}
              <div className="relative w-full sm:w-72">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="text"
                  placeholder="Cari mata kuliah, dosen, ruang..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700/80 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition"
                />
              </div>
            </div>

            {/* Schedules by Day */}
            {loading ? (
              <div className="p-12 text-center text-slate-400 text-xs">Memuat data jadwal...</div>
            ) : filteredSchedules.length === 0 ? (
              <div className="p-12 text-center rounded-xl bg-slate-900/40 border border-slate-800 text-slate-400 text-xs">
                Tidak ada jadwal kuliah yang cocok dengan filter.
              </div>
            ) : (
              <div className="space-y-6">
                {daysWithSchedules.map((group) => {
                  if (group.items.length === 0) return null;
                  return (
                    <div key={group.dayNum} className="space-y-3">
                      {/* Day Header */}
                      <div className="flex items-center space-x-3">
                        <span className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
                        <h3 className="text-base font-bold text-white tracking-wide">
                          Hari {group.dayName}
                        </h3>
                        <span className="text-xs text-slate-400 font-mono">
                          ({group.items.length} sesi perkuliahan)
                        </span>
                        <div className="flex-1 h-[1px] bg-slate-800" />
                      </div>

                      {/* Items Grid */}
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {group.items.map((item) => (
                          <div
                            key={item.id}
                            className="p-4 rounded-xl bg-[#0b1120] border border-slate-800 hover:border-cyan-500/40 transition-all space-y-3 relative group flex flex-col justify-between"
                          >
                            <div>
                              <div className="flex items-center justify-between mb-2">
                                <span className="px-2 py-0.5 rounded bg-blue-950/80 border border-blue-500/40 text-cyan-300 text-[11px] font-mono font-bold flex items-center space-x-1">
                                  <Clock className="w-3 h-3 text-cyan-400" />
                                  <span>{item.startTime} - {item.endTime}</span>
                                </span>
                                <span className="px-1.5 py-0.5 rounded bg-slate-800 text-[10px] font-mono text-slate-300 border border-slate-700">
                                  {item.courseSks} SKS
                                </span>
                              </div>

                              <h4 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">
                                {item.courseName}
                              </h4>
                              <p className="text-[11px] text-slate-400 font-mono mt-0.5">
                                Kode: {item.courseCode}
                              </p>
                              {item.courseDescription && (
                                <p className="text-xs text-slate-400 mt-2 line-clamp-2 leading-relaxed">
                                  {item.courseDescription}
                                </p>
                              )}
                            </div>

                            <div className="pt-3 border-t border-slate-800/80 space-y-1.5 text-xs text-slate-300">
                              <div className="flex items-center space-x-1.5">
                                <User className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                                <span className="text-slate-200 truncate">{item.lecturerName}</span>
                              </div>
                              <div className="flex items-center space-x-1.5 text-[11px]">
                                <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                                <span className="font-mono text-emerald-300 font-medium">{item.room}</span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ========================================================= */}
        {/* VIEW 2: MONTHLY INTERACTIVE CALENDAR */}
        {/* ========================================================= */}
        {viewMode === 'calendar' && (
          <div className="space-y-6">
            {/* Calendar Controls */}
            <div className="flex flex-col sm:flex-row items-center justify-between p-4 bg-[#0b1120] rounded-xl border border-slate-800 gap-3">
              <div className="flex items-center space-x-2">
                <button
                  onClick={handlePrevMonth}
                  className="p-2 rounded-lg bg-slate-900 border border-slate-700 text-slate-300 hover:text-white hover:bg-slate-800 transition"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <div className="px-4 py-1.5 bg-slate-900 rounded-lg border border-slate-700 text-sm font-bold text-white font-mono text-center min-w-[180px]">
                  {MONTH_NAMES[currentMonth]} {currentYear}
                </div>
                <button
                  onClick={handleNextMonth}
                  className="p-2 rounded-lg bg-slate-900 border border-slate-700 text-slate-300 hover:text-white hover:bg-slate-800 transition"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={handleCurrentMonth}
                  className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800 transition"
                >
                  Bulan Ini
                </button>
                <div className="flex items-center space-x-1.5 text-xs text-slate-400 font-mono">
                  <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 inline-block" />
                  <span>Ada Kelas Perkuliahan</span>
                </div>
              </div>
            </div>

            {/* Grid & Selected Day Inspector */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Left: 7-Column Calendar Grid */}
              <div className="lg:col-span-8 bg-[#0b1120] p-4 rounded-xl border border-slate-800">
                {/* Weekday Names Header */}
                <div className="grid grid-cols-7 gap-1 text-center font-mono text-xs font-bold text-slate-400 mb-2 pb-2 border-b border-slate-800">
                  <span className="text-slate-500">Sen</span>
                  <span className="text-slate-500">Sel</span>
                  <span className="text-slate-500">Rab</span>
                  <span className="text-slate-500">Kam</span>
                  <span className="text-slate-500">Jum</span>
                  <span className="text-rose-400">Sab</span>
                  <span className="text-rose-400">Min</span>
                </div>

                {calendarLoading ? (
                  <div className="p-16 text-center text-slate-400 text-xs">Memuat kalender...</div>
                ) : calendarData ? (
                  <div className="grid grid-cols-7 gap-1.5">
                    {/* Leading blanks for alignment: dayOfWeek of 1st day (1=Senin ... 7=Minggu) */}
                    {Array.from({ length: (calendarData.days[0]?.dayOfWeek || 1) - 1 }).map((_, i) => (
                      <div key={`blank-${i}`} className="min-h-[64px] rounded-lg bg-slate-950/20 border border-transparent" />
                    ))}

                    {/* Day Cells */}
                    {calendarData.days.map((day) => {
                      const isSelected = selectedCalendarDay?.date === day.date;
                      const isWeekend = day.dayOfWeek === 6 || day.dayOfWeek === 7;
                      const todayStr = new Date().toISOString().split('T')[0];
                      const isToday = day.date === todayStr;

                      return (
                        <div
                          key={day.date}
                          onClick={() => setSelectedCalendarDay(day)}
                          className={`min-h-[70px] p-2 rounded-lg border transition-all cursor-pointer flex flex-col justify-between ${
                            isSelected
                              ? 'bg-blue-950/70 border-cyan-400 shadow-md shadow-cyan-500/10'
                              : day.hasClasses
                              ? 'bg-slate-900/90 border-slate-800 hover:border-cyan-500/40 hover:bg-slate-850'
                              : 'bg-slate-950/40 border-slate-900/60 hover:bg-slate-900/50'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span
                              className={`text-xs font-mono font-bold ${
                                isToday
                                  ? 'px-1.5 py-0.5 rounded bg-cyan-500 text-black'
                                  : isWeekend
                                  ? 'text-rose-400'
                                  : 'text-slate-300'
                              }`}
                            >
                              {day.dayNumber}
                            </span>
                            {day.hasClasses && (
                              <span className="w-2 h-2 rounded-full bg-cyan-400 shadow-sm shadow-cyan-400" />
                            )}
                          </div>

                          {day.hasClasses && (
                            <div className="mt-1">
                              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-blue-950 text-cyan-300 border border-cyan-500/30 line-clamp-1 block">
                                {day.schedules.length} Kelas
                              </span>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                ) : null}
              </div>

              {/* Right: Selected Day Details */}
              <div className="lg:col-span-4 bg-[#0b1120] p-4 rounded-xl border border-slate-800 flex flex-col">
                <div className="pb-3 border-b border-slate-800">
                  <div className="flex items-center space-x-2 text-xs text-cyan-400 font-mono">
                    <CalendarIcon className="w-3.5 h-3.5" />
                    <span>RINCIAN TANGGAL</span>
                  </div>
                  <h4 className="text-base font-bold text-white mt-1">
                    {selectedCalendarDay
                      ? `${DAY_NAMES[selectedCalendarDay.dayOfWeek]}, ${selectedCalendarDay.dayNumber} ${MONTH_NAMES[currentMonth]} ${currentYear}`
                      : 'Pilih tanggal di kalender'}
                  </h4>
                </div>

                <div className="mt-4 flex-1 overflow-y-auto space-y-3">
                  {!selectedCalendarDay ? (
                    <p className="text-xs text-slate-400 text-center py-8">
                      Klik salah satu tanggal pada kalender untuk melihat daftar perkuliahan.
                    </p>
                  ) : !selectedCalendarDay.hasClasses ? (
                    <div className="text-center py-8 text-slate-400 space-y-2">
                      <div className="w-10 h-10 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center mx-auto text-slate-500">
                        <CheckCircle className="w-5 h-5" />
                      </div>
                      <p className="text-xs font-semibold text-slate-300">Tidak ada jadwal kuliah</p>
                      <p className="text-[11px] text-slate-500">Hari ini bebas dari perkuliahan rutin.</p>
                    </div>
                  ) : (
                    selectedCalendarDay.schedules.map((item, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-lg bg-slate-900/90 border border-slate-800 space-y-2 text-xs"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-mono text-cyan-400 font-bold">
                            {item.startTime} - {item.endTime}
                          </span>
                          <span className="px-1.5 py-0.5 rounded bg-slate-800 text-[10px] font-mono text-slate-300">
                            {item.courseCode} ({item.courseSks} SKS)
                          </span>
                        </div>
                        <p className="font-bold text-white text-sm">{item.courseName}</p>
                        <div className="space-y-1 text-slate-300 text-[11px] pt-1 border-t border-slate-800">
                          <div className="flex items-center space-x-1.5">
                            <User className="w-3 h-3 text-blue-400" />
                            <span>{item.lecturerName}</span>
                          </div>
                          <div className="flex items-center space-x-1.5">
                            <MapPin className="w-3 h-3 text-emerald-400" />
                            <span className="font-mono font-medium text-emerald-300">{item.room}</span>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

            </div>
          </div>
        )}

      </div>
    </section>
  );
};
