import React, { useState, useEffect } from 'react';
import { Users, Search, Filter, Shield, Award, UserCheck, Hash, Layers } from 'lucide-react';
import { Student } from '../types.ts';
import { api } from '../services/api.ts';

export const ClassStructure: React.FC = () => {
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const [selectedDivision, setSelectedDivision] = useState<string>('Semua');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const loadStudents = async () => {
    setLoading(true);
    try {
      const data = await api.getStudents();
      setStudents(data);
    } catch (err: any) {
      setError(err.message || 'Gagal memuat data mahasiswa.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStudents();
  }, []);

  const divisions = [
    'Semua',
    'Pengurus Harian',
    'Akademik & Riset',
    'Humas & Publikasi',
    'Kreatif & Logistik',
    'Anggota Kelas',
  ];

  const filteredStudents = students.filter((s) => {
    const matchDiv = selectedDivision === 'Semua' || s.division === selectedDivision;
    const matchSearch =
      searchQuery === '' ||
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.npm.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.position.toLowerCase().includes(searchQuery.toLowerCase());
    return matchDiv && matchSearch;
  });

  // Key officers for tree view
  const ketua = students.find((s) => s.position === 'Ketua Kelas') || students[0];
  const wakil = students.find((s) => s.position === 'Wakil Ketua') || students[1];
  const sekretaris = students.find((s) => s.position === 'Sekretaris') || students[2];
  const bendahara = students.find((s) => s.position === 'Bendahara') || students[3];

  return (
    <section id="struktur" className="py-16 border-b border-slate-800/80 bg-[#070b14]/70 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <div className="inline-flex items-center space-x-2 px-2.5 py-1 rounded bg-blue-950/80 border border-blue-500/40 text-cyan-400 text-xs font-mono mb-2">
              <Users className="w-3.5 h-3.5 text-cyan-400" />
              <span>DIREKTORI MAHASISWA RESMI TI 1C</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Struktur Kepengurusan & Anggota Kelas
            </h2>
            <p className="text-sm text-slate-400 mt-1">
              Hierarki kepemimpinan dan direktori lengkap 35 mahasiswa Teknik Informatika 1C.
            </p>
          </div>

          <div className="flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-slate-300">Total Anggota:</span>
            <span className="text-cyan-400 font-bold">{students.length} / 35 Mahasiswa</span>
          </div>
        </div>

        {/* ========================================================= */}
        {/* TOP LEVEL HIERARCHY TREE (Pengurus Harian) */}
        {/* ========================================================= */}
        <div className="mb-12 p-6 rounded-2xl bg-[#0b1120] border border-slate-800 relative overflow-hidden">
          <div className="flex items-center justify-between mb-6 pb-3 border-b border-slate-800">
            <div className="flex items-center space-x-2">
              <Award className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm font-bold text-white tracking-wider font-mono">
                BADAN PENGURUS HARIAN (BPH)
              </h3>
            </div>
            <span className="text-xs text-slate-400 font-mono">Periode 2026/2027</span>
          </div>

          {loading ? (
            <div className="py-12 text-center text-xs text-slate-400">Memuat struktur organisasi...</div>
          ) : (
            <div className="space-y-6">
              {/* Level 1: Ketua Kelas */}
              {ketua && (
                <div className="flex justify-center">
                  <div className="w-full max-w-sm p-4 rounded-xl bg-gradient-to-b from-blue-950/60 to-slate-900 border border-cyan-500/50 text-center shadow-lg shadow-cyan-500/10 relative">
                    <div className="w-12 h-12 rounded-full bg-blue-600/30 border border-cyan-400 flex items-center justify-center mx-auto mb-2 text-cyan-300 font-bold font-mono">
                      01
                    </div>
                    <span className="px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-500/40 text-[10px] font-extrabold uppercase tracking-wider">
                      {ketua.position}
                    </span>
                    <h4 className="text-base font-bold text-white mt-2">{ketua.name}</h4>
                    <p className="text-xs text-slate-400 font-mono mt-0.5">NPM: {ketua.npm}</p>
                  </div>
                </div>
              )}

              {/* Connecting vertical line */}
              <div className="w-[2px] h-6 bg-cyan-500/40 mx-auto" />

              {/* Level 2: Wakil, Sekretaris, Bendahara */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-4xl mx-auto">
                {/* Wakil */}
                {wakil && (
                  <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-700/80 text-center hover:border-cyan-500/40 transition">
                    <div className="w-10 h-10 rounded-full bg-slate-800 border border-slate-600 flex items-center justify-center mx-auto mb-2 text-slate-300 font-bold font-mono text-xs">
                      02
                    </div>
                    <span className="px-2 py-0.5 rounded bg-blue-950 text-blue-300 text-[10px] font-bold uppercase">
                      {wakil.position}
                    </span>
                    <h5 className="text-sm font-bold text-white mt-1.5">{wakil.name}</h5>
                    <p className="text-xs text-slate-400 font-mono mt-0.5">{wakil.npm}</p>
                  </div>
                )}

                {/* Sekretaris */}
                {sekretaris && (
                  <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-700/80 text-center hover:border-cyan-500/40 transition">
                    <div className="w-10 h-10 rounded-full bg-slate-800 border border-slate-600 flex items-center justify-center mx-auto mb-2 text-slate-300 font-bold font-mono text-xs">
                      03
                    </div>
                    <span className="px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 text-[10px] font-bold uppercase">
                      {sekretaris.position}
                    </span>
                    <h5 className="text-sm font-bold text-white mt-1.5">{sekretaris.name}</h5>
                    <p className="text-xs text-slate-400 font-mono mt-0.5">{sekretaris.npm}</p>
                  </div>
                )}

                {/* Bendahara */}
                {bendahara && (
                  <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-700/80 text-center hover:border-cyan-500/40 transition">
                    <div className="w-10 h-10 rounded-full bg-slate-800 border border-slate-600 flex items-center justify-center mx-auto mb-2 text-slate-300 font-bold font-mono text-xs">
                      04
                    </div>
                    <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 text-[10px] font-bold uppercase">
                      {bendahara.position}
                    </span>
                    <h5 className="text-sm font-bold text-white mt-1.5">{bendahara.name}</h5>
                    <p className="text-xs text-slate-400 font-mono mt-0.5">{bendahara.npm}</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* ========================================================= */}
        {/* DIRECTORY OF ALL 35 STUDENTS */}
        {/* ========================================================= */}
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row gap-3 items-center justify-between bg-[#0b1120] p-4 rounded-xl border border-slate-800">
            {/* Division Filter */}
            <div className="flex flex-wrap items-center gap-1.5 w-full sm:w-auto">
              {divisions.map((div) => (
                <button
                  key={div}
                  onClick={() => setSelectedDivision(div)}
                  className={`px-3 py-1.5 rounded-md text-xs font-medium transition ${
                    selectedDivision === div
                      ? 'bg-blue-600 text-white font-semibold shadow-sm'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  {div}
                </button>
              ))}
            </div>

            {/* Search Box */}
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                placeholder="Cari nama atau NPM..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700/80 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition"
              />
            </div>
          </div>

          {/* Directory Grid */}
          {loading ? (
            <div className="p-12 text-center text-xs text-slate-400">Memuat direktori mahasiswa...</div>
          ) : filteredStudents.length === 0 ? (
            <div className="p-12 text-center rounded-xl bg-slate-900/40 border border-slate-800 text-slate-400 text-xs">
              Tidak ada mahasiswa yang cocok dengan kriteria pencarian.
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredStudents.map((mhs) => {
                const padNum = String(mhs.orderIndex).padStart(2, '0');
                const isLeader = mhs.orderIndex <= 4;

                return (
                  <div
                    key={mhs.id}
                    className="p-4 rounded-xl bg-[#0b1120] border border-slate-800/90 hover:border-cyan-500/40 hover:bg-slate-850 transition-all flex flex-col justify-between space-y-3"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-3">
                        <div
                          className={`w-10 h-10 rounded-lg flex items-center justify-center font-mono text-xs font-bold ${
                            isLeader
                              ? 'bg-blue-600/20 text-cyan-400 border border-cyan-500/40'
                              : 'bg-slate-800 text-slate-300 border border-slate-700'
                          }`}
                        >
                          {padNum}
                        </div>
                        <div>
                          <h4 className="text-sm font-bold text-white">{mhs.name}</h4>
                          <span className="text-xs text-slate-400 font-mono flex items-center space-x-1 mt-0.5">
                            <Hash className="w-3 h-3 text-slate-500" />
                            <span>{mhs.npm}</span>
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                      <span className="text-slate-400 font-medium truncate max-w-[130px]">
                        {mhs.division}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          isLeader
                            ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/30'
                            : 'bg-slate-800 text-slate-300'
                        }`}
                      >
                        {mhs.position}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

        </div>

      </div>
    </section>
  );
};
