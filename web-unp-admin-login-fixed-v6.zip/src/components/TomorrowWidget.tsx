import React, { useState, useEffect } from 'react';
import { Calendar, Clock, MapPin, User, Sparkles, Coffee, AlertCircle, RefreshCw, ChevronRight } from 'lucide-react';
import { ScheduleItem, TomorrowScheduleResponse } from '../types.ts';
import { api } from '../services/api.ts';

interface TomorrowWidgetProps {
  onViewAllSchedules: () => void;
}

export const TomorrowWidget: React.FC<TomorrowWidgetProps> = ({ onViewAllSchedules }) => {
  const [tomorrowData, setTomorrowData] = useState<TomorrowScheduleResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [allSchedules, setAllSchedules] = useState<ScheduleItem[]>([]);
  
  // Custom selector: 'tomorrow' | 'today' | 'mon' | 'tue' | 'wed' | 'thu' | 'fri'
  const [activeTab, setActiveTab] = useState<'tomorrow' | 1 | 2 | 3 | 4 | 5>('tomorrow');

  const fetchTomorrow = async () => {
    setLoading(true);
    setError(null);
    try {
      const [tomorrowRes, schedulesRes] = await Promise.all([
        api.getTomorrowSchedule(),
        api.getSchedules(),
      ]);
      setTomorrowData(tomorrowRes);
      setAllSchedules(schedulesRes);
    } catch (err: any) {
      setError(err.message || 'Gagal memuat jadwal.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTomorrow();
  }, []);

  // Compute what classes to display based on activeTab
  const getDisplayedClasses = (): { title: string; subtitle: string; classes: ScheduleItem[]; isOffDay: boolean } => {
    if (activeTab === 'tomorrow') {
      return {
        title: tomorrowData?.dayName ? `Besok (${tomorrowData.dayName})` : 'Besok',
        subtitle: tomorrowData?.dateFormatted || 'Sinkronisasi Waktu Indonesia Barat (WIB)',
        classes: tomorrowData?.classes || [],
        isOffDay: !tomorrowData?.hasClasses,
      };
    }

    // Days mapping: 1 = Senin, 2 = Selasa, 3 = Rabu, 4 = Kamis, 5 = Jumat
    const dayNames: Record<number, string> = {
      1: 'Senin',
      2: 'Selasa',
      3: 'Rabu',
      4: 'Kamis',
      5: 'Jumat',
    };

    const matching = allSchedules.filter((s) => s.dayOfWeek === activeTab);
    return {
      title: `Jadwal Hari ${dayNames[activeTab]}`,
      subtitle: `Perkuliahan Rutin Semester Ganjil TI 1C`,
      classes: matching,
      isOffDay: matching.length === 0,
    };
  };

  const displayed = getDisplayedClasses();

  return (
    <section id="besok" className="py-14 border-b border-slate-800/80 bg-[#070b14]/50 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <div className="inline-flex items-center space-x-2 px-2.5 py-1 rounded-md bg-blue-950/80 border border-blue-500/40 text-blue-400 text-xs font-mono mb-2">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>INTELLIGENT SCHEDULE RESOLVER</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Besok Kuliah Apa?
            </h2>
            <p className="text-sm text-slate-400 mt-1">
              Menghitung jadwal otomatis berdasarkan hari, tanggal, dan waktu Indonesia Barat (UTC+7).
            </p>
          </div>

          {/* Day Switcher Selector */}
          <div className="flex flex-wrap items-center gap-1.5 bg-slate-900/90 p-1.5 rounded-lg border border-slate-800">
            <button
              onClick={() => setActiveTab('tomorrow')}
              className={`px-3 py-1.5 rounded text-xs font-medium transition ${
                activeTab === 'tomorrow'
                  ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white font-semibold shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              Besok {tomorrowData?.dayName ? `(${tomorrowData.dayName})` : ''}
            </button>
            <button
              onClick={() => setActiveTab(1)}
              className={`px-2.5 py-1.5 rounded text-xs font-medium transition ${
                activeTab === 1
                  ? 'bg-blue-600 text-white font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              Senin
            </button>
            <button
              onClick={() => setActiveTab(2)}
              className={`px-2.5 py-1.5 rounded text-xs font-medium transition ${
                activeTab === 2
                  ? 'bg-blue-600 text-white font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              Selasa
            </button>
            <button
              onClick={() => setActiveTab(3)}
              className={`px-2.5 py-1.5 rounded text-xs font-medium transition ${
                activeTab === 3
                  ? 'bg-blue-600 text-white font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              Rabu
            </button>
            <button
              onClick={() => setActiveTab(4)}
              className={`px-2.5 py-1.5 rounded text-xs font-medium transition ${
                activeTab === 4
                  ? 'bg-blue-600 text-white font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              Kamis
            </button>
            <button
              onClick={() => setActiveTab(5)}
              className={`px-2.5 py-1.5 rounded text-xs font-medium transition ${
                activeTab === 5
                  ? 'bg-blue-600 text-white font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              Jumat
            </button>

            <button
              onClick={fetchTomorrow}
              title="Perbarui Data"
              className="p-1.5 rounded text-slate-400 hover:text-cyan-400 hover:bg-slate-800 transition"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        {/* Content Box */}
        {loading && (
          <div className="p-12 text-center rounded-xl bg-slate-900/50 border border-slate-800/80">
            <RefreshCw className="w-8 h-8 text-cyan-400 animate-spin mx-auto mb-3" />
            <p className="text-sm text-slate-300">Menghitung kalender akademik perkuliahan...</p>
          </div>
        )}

        {error && !loading && (
          <div className="p-6 rounded-xl bg-rose-950/40 border border-rose-800 text-center">
            <AlertCircle className="w-8 h-8 text-rose-400 mx-auto mb-2" />
            <p className="text-sm text-rose-300">{error}</p>
            <button
              onClick={fetchTomorrow}
              className="mt-3 px-3 py-1.5 bg-rose-900/60 hover:bg-rose-800 text-white rounded text-xs font-semibold"
            >
              Coba Lagi
            </button>
          </div>
        )}

        {!loading && !error && (
          <div>
            {/* Status Bar */}
            <div className="flex items-center justify-between p-3.5 rounded-t-xl bg-slate-900/80 border-t border-x border-slate-800">
              <div className="flex items-center space-x-2">
                <Calendar className="w-4 h-4 text-cyan-400" />
                <span className="text-sm font-bold text-white">{displayed.title}</span>
                <span className="text-xs text-slate-400 hidden sm:inline">• {displayed.subtitle}</span>
              </div>
              <div>
                {displayed.isOffDay ? (
                  <span className="px-2.5 py-1 rounded bg-amber-950/60 border border-amber-500/40 text-amber-300 text-xs font-semibold">
                    Libur / Tidak Ada Kelas
                  </span>
                ) : (
                  <span className="px-2.5 py-1 rounded bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs font-semibold">
                    {displayed.classes.length} Mata Kuliah Terjadwal
                  </span>
                )}
              </div>
            </div>

            {/* If Off Day */}
            {displayed.isOffDay ? (
              <div className="p-8 sm:p-12 text-center rounded-b-xl bg-[#0b1120] border border-slate-800 flex flex-col items-center justify-center">
                <div className="w-14 h-14 rounded-full bg-slate-800/80 border border-slate-700 flex items-center justify-center mb-4 text-amber-400">
                  <Coffee className="w-7 h-7" />
                </div>
                <h3 className="text-lg font-bold text-slate-100 mb-1">
                  Tidak Ada Perkuliahan Terjadwal
                </h3>
                <p className="text-xs text-slate-400 max-w-md leading-relaxed">
                  Tidak ada kelas untuk {displayed.title.toLowerCase()}. Waktunya beristirahat, mengerjakan tugas kelompok, atau mereview praktikum pemrograman.
                </p>
                <button
                  onClick={onViewAllSchedules}
                  className="mt-5 flex items-center space-x-2 text-xs text-cyan-400 hover:text-cyan-300 font-semibold"
                >
                  <span>Lihat Jadwal Hari Lainnya di Kalender</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            ) : (
              /* If Has Classes */
              <div className="p-5 rounded-b-xl bg-[#0b1120] border border-slate-800 space-y-3">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {displayed.classes.map((item, idx) => (
                    <div
                      key={item.id || idx}
                      className="p-4 rounded-lg bg-slate-900/90 border border-slate-800/90 hover:border-cyan-500/50 hover:bg-slate-850 transition-all space-y-3 relative group"
                    >
                      {/* Top row: Time & SKS */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-1.5 px-2.5 py-1 rounded bg-blue-950/80 border border-blue-500/40 text-cyan-300 text-xs font-mono font-bold">
                          <Clock className="w-3.5 h-3.5 text-cyan-400" />
                          <span>{item.startTime} - {item.endTime} WIB</span>
                        </div>
                        <div className="flex items-center space-x-1.5">
                          <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] font-mono text-slate-300 font-bold border border-slate-700">
                            {item.courseCode}
                          </span>
                          <span className="px-2 py-0.5 rounded bg-cyan-950/60 text-[10px] font-bold text-cyan-400 border border-cyan-500/30">
                            {item.courseSks} SKS
                          </span>
                        </div>
                      </div>

                      {/* Course Title */}
                      <div>
                        <h4 className="text-base font-bold text-white group-hover:text-cyan-300 transition-colors">
                          {item.courseName}
                        </h4>
                        {item.courseDescription && (
                          <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                            {item.courseDescription}
                          </p>
                        )}
                      </div>

                      {/* Lecturer and Room Info */}
                      <div className="pt-2 border-t border-slate-800 flex flex-wrap items-center justify-between text-xs text-slate-300 gap-2">
                        <div className="flex items-center space-x-1.5">
                          <User className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                          <span className="font-medium text-slate-200">{item.lecturerName}</span>
                        </div>
                        <div className="flex items-center space-x-1.5 px-2 py-0.5 rounded bg-slate-800/70 border border-slate-700 text-slate-300">
                          <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          <span className="font-mono text-[11px] font-semibold">{item.room}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    onClick={onViewAllSchedules}
                    className="flex items-center space-x-1 text-xs text-slate-400 hover:text-cyan-400 font-medium transition"
                  >
                    <span>Buka Jadwal Mingguan Lengkap</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

      </div>
    </section>
  );
};
