import React, { useState } from 'react';
import { Terminal as TerminalIcon, Calendar, ArrowRight, ShieldCheck, Users, BookOpen, Layers, CheckCircle2 } from 'lucide-react';

interface HeroProps {
  onNavigate: (sectionId: string) => void;
  stats?: {
    studentsCount: number;
    coursesCount: number;
    lecturersCount: number;
    schedulesCount: number;
  };
}

export const Hero: React.FC<HeroProps> = ({ onNavigate, stats }) => {
  const [terminalTab, setTerminalTab] = useState<'status' | 'env' | 'rules'>('status');

  const studentsTotal = stats?.studentsCount ?? 35;
  const coursesTotal = stats?.coursesCount ?? 6;
  const lecturersTotal = stats?.lecturersCount ?? 5;

  return (
    <section id="beranda" className="relative pt-8 pb-16 overflow-hidden border-b border-slate-800/80 bg-digital-grid">
      {/* Ambient background glows */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/3 right-10 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          {/* Left Column: Heading, Info & CTAs */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* System Tag */}
            <div className="inline-flex items-center space-x-2 px-3 py-1.5 rounded-full bg-slate-900/90 border border-cyan-500/30 text-xs font-mono text-cyan-400">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              <span>PORTAL INFORMASI RESMI // TAHUN AKADEMIK 2026/2027</span>
            </div>

            {/* University & Title */}
            <div>
              <p className="text-xs sm:text-sm font-semibold tracking-widest text-slate-400 uppercase font-mono mb-1">
                UNIVERSITAS NUSANTARA PGRI KEDIRI • FAKULTAS TEKNIK
              </p>
              <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-none">
                TEKNIK INFORMATIKA <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-cyan-400 to-teal-300">1C</span>
              </h1>
            </div>

            {/* Tagline Box */}
            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/90 backdrop-blur-sm">
              <div className="flex items-center space-x-2 text-cyan-400 font-mono text-xs font-semibold mb-1">
                <span className="text-blue-400">#</span>
                <span>MOTTO & IDENTITAS KELAS</span>
              </div>
              <p className="text-xl sm:text-2xl font-black text-slate-100 tracking-wider font-mono">
                35 MAHASISWA <span className="text-cyan-400">•</span> 1 KELAS <span className="text-cyan-400">•</span> 1 CERITA
              </p>
              <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                Pusat data terintegrasi perkuliahan semester ganjil, jadwal kuliah harian real-time dengan sinkronisasi waktu Indonesia Barat, direktori lengkap 35 mahasiswa, dosen pengampu, dan pengumuman resmi.
              </p>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-3 gap-3">
              <div className="p-3 rounded-lg bg-slate-900/80 border border-slate-800 text-center">
                <p className="text-2xl font-black text-cyan-400 font-mono">{studentsTotal}</p>
                <p className="text-[11px] text-slate-400 font-medium">Mahasiswa Terdaftar</p>
              </div>
              <div className="p-3 rounded-lg bg-slate-900/80 border border-slate-800 text-center">
                <p className="text-2xl font-black text-blue-400 font-mono">{coursesTotal}</p>
                <p className="text-[11px] text-slate-400 font-medium">Mata Kuliah Aktif</p>
              </div>
              <div className="p-3 rounded-lg bg-slate-900/80 border border-slate-800 text-center">
                <p className="text-2xl font-black text-emerald-400 font-mono">{lecturersTotal}</p>
                <p className="text-[11px] text-slate-400 font-medium">Dosen Pengampu</p>
              </div>
            </div>

            {/* CTAs */}
            <div className="flex flex-wrap gap-3 pt-2">
              <button
                id="hero-cta-tomorrow"
                onClick={() => onNavigate('besok')}
                className="flex items-center space-x-2 px-5 py-3 rounded-lg bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-semibold text-xs tracking-wide shadow-lg shadow-cyan-500/20 transition-all cursor-pointer"
              >
                <Calendar className="w-4 h-4" />
                <span>Besok Kuliah Apa?</span>
                <ArrowRight className="w-4 h-4 ml-1" />
              </button>

              <button
                id="hero-cta-schedules"
                onClick={() => onNavigate('jadwal')}
                className="flex items-center space-x-2 px-4 py-3 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-semibold transition-all cursor-pointer"
              >
                <Layers className="w-4 h-4 text-cyan-400" />
                <span>Lihat Jadwal & Kalender</span>
              </button>

              <button
                id="hero-cta-students"
                onClick={() => onNavigate('struktur')}
                className="flex items-center space-x-2 px-4 py-3 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-medium transition cursor-pointer"
              >
                <Users className="w-4 h-4 text-blue-400" />
                <span>Struktur Kelas</span>
              </button>
            </div>

          </div>

          {/* Right Column: Interactive Terminal Box */}
          <div className="lg:col-span-5">
            <div className="rounded-xl bg-[#0b1120] border border-slate-700/80 shadow-2xl overflow-hidden font-mono text-xs">
              
              {/* Terminal Header */}
              <div className="flex items-center justify-between px-4 py-3 bg-[#070b14] border-b border-slate-800">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 rounded-full bg-rose-500/80" />
                  <div className="w-3 h-3 rounded-full bg-amber-500/80" />
                  <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
                  <span className="ml-2 text-[11px] text-slate-400 font-semibold">ti1c-node-portal — zsh</span>
                </div>
                <div className="flex items-center space-x-1 text-[10px] text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                  <ShieldCheck className="w-3 h-3 text-emerald-400" />
                  <span>SECURE V2.6</span>
                </div>
              </div>

              {/* Terminal Subtabs */}
              <div className="flex border-b border-slate-800 bg-slate-950/60 px-2 pt-2 space-x-1">
                <button
                  onClick={() => setTerminalTab('status')}
                  className={`px-3 py-1.5 rounded-t text-[11px] transition ${
                    terminalTab === 'status'
                      ? 'bg-[#0b1120] text-cyan-400 border-t border-x border-slate-700 font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  system.status
                </button>
                <button
                  onClick={() => setTerminalTab('env')}
                  className={`px-3 py-1.5 rounded-t text-[11px] transition ${
                    terminalTab === 'env'
                      ? 'bg-[#0b1120] text-cyan-400 border-t border-x border-slate-700 font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  security.manifest
                </button>
                <button
                  onClick={() => setTerminalTab('rules')}
                  className={`px-3 py-1.5 rounded-t text-[11px] transition ${
                    terminalTab === 'rules'
                      ? 'bg-[#0b1120] text-cyan-400 border-t border-x border-slate-700 font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  database.schema
                </button>
              </div>

              {/* Terminal Content */}
              <div className="p-4 space-y-3 min-h-[260px] text-slate-300">
                {terminalTab === 'status' && (
                  <>
                    <div className="flex items-center space-x-2 text-cyan-400">
                      <span>$</span>
                      <span className="text-white">ti1c-cli status --verbose</span>
                    </div>
                    <div className="space-y-1 text-slate-300 text-[11px] pl-2 border-l border-slate-800">
                      <p><span className="text-slate-400">Univ:</span> UNIVERSITAS NUSANTARA PGRI KEDIRI</p>
                      <p><span className="text-slate-400">Prodi:</span> TEKNIK INFORMATIKA (1C)</p>
                      <p><span className="text-slate-400">Kapasitas:</span> 35 Mahasiswa Aktif [NPM: 24.1.03.02.xxxx]</p>
                      <p><span className="text-slate-400">Timezone:</span> Asia/Jakarta (WIB UTC+7)</p>
                      <p><span className="text-slate-400">Jadwal Aktif:</span> 7 Sesi Kuliah Mingguan</p>
                    </div>
                    <div className="p-2.5 rounded bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-[11px] flex items-center space-x-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>Sistem siap: Seluruh modul akademik & sinkronisasi jadwal online.</span>
                    </div>
                  </>
                )}

                {terminalTab === 'env' && (
                  <>
                    <div className="flex items-center space-x-2 text-cyan-400">
                      <span>$</span>
                      <span className="text-white">check-security-posture</span>
                    </div>
                    <div className="space-y-1.5 text-[11px] text-slate-300">
                      <div className="flex justify-between items-center bg-slate-900/60 p-1.5 rounded">
                        <span className="text-slate-400">Password Hashing</span>
                        <span className="text-cyan-400">bcryptjs (Cost: 10)</span>
                      </div>
                      <div className="flex justify-between items-center bg-slate-900/60 p-1.5 rounded">
                        <span className="text-slate-400">Auth Token</span>
                        <span className="text-emerald-400">HttpOnly Secure Cookie</span>
                      </div>
                      <div className="flex justify-between items-center bg-slate-900/60 p-1.5 rounded">
                        <span className="text-slate-400">Rate Limiting</span>
                        <span className="text-amber-300">Active (5 req / 15 min)</span>
                      </div>
                      <div className="flex justify-between items-center bg-slate-900/60 p-1.5 rounded">
                        <span className="text-slate-400">Headers Protection</span>
                        <span className="text-blue-300">Helmet CSP + XSS Guard</span>
                      </div>
                    </div>
                  </>
                )}

                {terminalTab === 'rules' && (
                  <>
                    <div className="flex items-center space-x-2 text-cyan-400">
                      <span>$</span>
                      <span className="text-white">sqlite-inspect --tables</span>
                    </div>
                    <div className="space-y-1 text-[11px] text-slate-300 font-mono">
                      <p className="text-blue-400">✓ tables: users (admin credential with bcrypt)</p>
                      <p className="text-cyan-400">✓ tables: students (35 records with NPM & roles)</p>
                      <p className="text-teal-400">✓ tables: courses (6 mata kuliah ber-SKS)</p>
                      <p className="text-emerald-400">✓ tables: lecturers (5 dosen pengampu & ruangan)</p>
                      <p className="text-indigo-400">✓ tables: schedules (with conflict checking)</p>
                      <p className="text-purple-400">✓ tables: audit_logs & announcements</p>
                    </div>
                  </>
                )}
              </div>

              {/* Terminal Footer */}
              <div className="px-4 py-2 bg-[#070b14] border-t border-slate-800 flex items-center justify-between text-[10px] text-slate-400">
                <span className="flex items-center space-x-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Daemon Online</span>
                </span>
                <span>Latency: 1ms (local)</span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
