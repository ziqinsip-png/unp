import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Volume2, VolumeX, Music, RotateCcw, ChevronDown, ChevronUp } from 'lucide-react';

export const MusicPlayer: React.FC = () => {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const progressBarRef = useRef<HTMLDivElement | null>(null);

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1.0);
  const [isMuted, setIsMuted] = useState(false);
  const [isLooping, setIsLooping] = useState(true);
  const [isCollapsed, setIsCollapsed] = useState(false);

  // Initialize and handle audio events
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    audio.volume = volume;
    audio.loop = isLooping;

    const onLoadedMetadata = () => {
      if (audio.duration && !isNaN(audio.duration)) {
        setDuration(audio.duration);
      }
    };

    const onTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
      if (audio.duration && !isNaN(audio.duration) && duration !== audio.duration) {
        setDuration(audio.duration);
      }
    };

    const onEnded = () => {
      if (!audio.loop) {
        setIsPlaying(false);
        setCurrentTime(audio.duration || 0);
      }
    };

    const onPlay = () => setIsPlaying(true);
    const onPause = () => setIsPlaying(false);

    const onError = () => {
      console.warn('Audio source error, switching to reliable local stream...');
      if (audio.src !== '/audio/music.mp3' && !audio.src.endsWith('/audio/music.mp3')) {
        audio.src = '/audio/music.mp3';
        audio.load();
        if (isPlaying) {
          audio.play().catch((err) => console.warn('Retry play:', err));
        }
      }
    };

    audio.addEventListener('loadedmetadata', onLoadedMetadata);
    audio.addEventListener('timeupdate', onTimeUpdate);
    audio.addEventListener('ended', onEnded);
    audio.addEventListener('play', onPlay);
    audio.addEventListener('pause', onPause);
    audio.addEventListener('error', onError);

    return () => {
      audio.removeEventListener('loadedmetadata', onLoadedMetadata);
      audio.removeEventListener('timeupdate', onTimeUpdate);
      audio.removeEventListener('ended', onEnded);
      audio.removeEventListener('play', onPlay);
      audio.removeEventListener('pause', onPause);
      audio.removeEventListener('error', onError);
    };
  }, [duration, isLooping, volume, isPlaying]);

  const togglePlay = () => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying) {
      audio.pause();
    } else {
      if (audio.volume === 0 || isMuted) {
        audio.volume = 1.0;
        audio.muted = false;
        setVolume(1.0);
        setIsMuted(false);
      }

      const playPromise = audio.play();
      if (playPromise !== undefined) {
        playPromise.catch((err) => {
          console.warn('Autoplay prevented or stream error, using fallback:', err);
          // Fallback to local audio directly
          if (!audio.src.endsWith('/audio/music.mp3')) {
            audio.src = '/audio/music.mp3';
            audio.load();
            audio.play().catch((e) => console.error('Playback failed:', e));
          }
        });
      }
    }
  };

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    const audio = audioRef.current;
    const bar = progressBarRef.current;
    if (!audio || !bar || !duration) return;

    const rect = bar.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const width = rect.width;
    const percentage = Math.max(0, Math.min(1, clickX / width));
    const newTime = percentage * duration;

    audio.currentTime = newTime;
    setCurrentTime(newTime);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    if (audioRef.current) {
      audioRef.current.volume = val;
      audioRef.current.muted = val === 0;
    }
    setIsMuted(val === 0);
  };

  const toggleMute = () => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isMuted) {
      audio.muted = false;
      setIsMuted(false);
      audio.volume = volume > 0 ? volume : 0.8;
      setVolume(audio.volume);
    } else {
      audio.muted = true;
      setIsMuted(true);
    }
  };

  const toggleLoop = () => {
    const audio = audioRef.current;
    const nextLoop = !isLooping;
    setIsLooping(nextLoop);
    if (audio) {
      audio.loop = nextLoop;
    }
  };

  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return '00:00';
    const mins = Math.floor(secs / 60);
    const remainderSecs = Math.floor(secs % 60);
    return `${String(mins).padStart(2, '0')}:${String(remainderSecs).padStart(2, '0')}`;
  };

  const progressPercent = duration > 0 ? Math.min(100, Math.max(0, (currentTime / duration) * 100)) : 0;

  return (
    <>
      {/* Audio element as specified in user request with multi-source fallback for instant sound */}
      <audio
        id="music"
        loop
        ref={audioRef}
        preload="auto"
        playsInline
      >
        {/* Instant reliable local MP3 stream (fixes Catbox delay, ISP blocking & demuxer issues) */}
        <source src="/audio/music.mp3" type="audio/mpeg" />
        <source src="/api/audio/stream" type="audio/mpeg" />
        {/* User requested original URL and type */}
        <source src="https://files.catbox.moe/fd63ue.mp3" type="audio/mp3" />
        <source src="https://files.catbox.moe/fd63ue.mp3" type="audio/mpeg" />
        <source src="https://files.catbox.moe/fd63ue.mp3" type="audio/mp4" />
        <source src="https://files.catbox.moe/fd63ue.mp3" />
      </audio>

      {/* Floating Modern Music Bar */}
      <div
        id="floating-music-player"
        className={`fixed bottom-4 left-1/2 -translate-x-1/2 z-40 w-[95%] max-w-2xl transition-all duration-300 ${
          isCollapsed ? 'translate-y-2' : ''
        }`}
      >
        <div className="relative rounded-2xl bg-slate-900/90 backdrop-blur-md border border-cyan-500/30 shadow-2xl shadow-cyan-950/50 p-3 sm:p-4 text-white">
          
          {/* Header row: Status, Title, and Collapse toggle */}
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2.5">
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${
                  isPlaying
                    ? 'bg-gradient-to-tr from-cyan-500 to-blue-600 shadow-md shadow-cyan-500/40 animate-pulse'
                    : 'bg-slate-800 text-slate-400'
                }`}
              >
                <Music className={`w-4 h-4 text-white ${isPlaying ? 'animate-spin-slow' : ''}`} />
              </div>
              <div className="flex flex-col">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-slate-100 tracking-wide flex items-center gap-1.5">
                    Musik Portal TI 1C
                    {isPlaying && (
                      <span className="inline-flex items-center gap-0.5 ml-1">
                        <span className="w-1 h-3 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
                        <span className="w-1 h-4 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
                        <span className="w-1 h-2.5 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
                      </span>
                    )}
                  </span>
                </div>
                <span className="text-[10px] text-slate-400">
                  {isPlaying ? 'Sedang diputar' : 'Musik dijeda'} • Loop: {isLooping ? 'Aktif' : 'Nonaktif'}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {/* Collapse/Expand Toggle */}
              <button
                id="toggle-player-collapse-btn"
                onClick={() => setIsCollapsed(!isCollapsed)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                title={isCollapsed ? 'Perbesar Pemutar Musik' : 'Perkecil Pemutar Musik'}
              >
                {isCollapsed ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {!isCollapsed && (
            <>
              {/* Animasi Garis Panjang (Progress Bar) */}
              <div className="my-2 space-y-1">
                <div
                  id="music-progress-container"
                  ref={progressBarRef}
                  onClick={handleSeek}
                  className="group relative w-full h-3 bg-slate-800 hover:h-3.5 rounded-full cursor-pointer overflow-hidden transition-all border border-slate-700/60"
                  title="Klik untuk geser posisi lagu"
                >
                  {/* Subtle track background line */}
                  <div className="absolute inset-0 bg-slate-800/80"></div>

                  {/* Filling Bar (Garis Panjang yang terisi penuh jika lagu habis) */}
                  <div
                    id="music-progress-fill"
                    className="h-full rounded-full transition-all duration-150 ease-linear bg-gradient-to-r from-blue-500 via-cyan-400 to-teal-300 shadow-[0_0_12px_rgba(34,211,238,0.7)]"
                    style={{ width: `${progressPercent}%` }}
                  >
                    {/* Glowing head effect */}
                    <div className="w-full h-full relative">
                      <div className="absolute right-0 top-0 bottom-0 w-2 bg-white/80 rounded-full shadow-sm"></div>
                    </div>
                  </div>
                </div>

                {/* Duration & Time Labels */}
                <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 px-0.5">
                  <span>{formatTime(currentTime)}</span>
                  <span className="text-cyan-400 font-medium">
                    {Math.round(progressPercent)}%
                  </span>
                  <span>{formatTime(duration)}</span>
                </div>
              </div>

              {/* Controls Row: Play/Pause, Loop, Volume */}
              <div className="flex items-center justify-between pt-1">
                {/* Play / Pause Main Button */}
                <div className="flex items-center gap-2">
                  <button
                    id="music-play-pause-btn"
                    onClick={togglePlay}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-500/25 transition active:scale-95"
                    title={isPlaying ? 'Jeda Musik' : 'Putar Musik'}
                  >
                    {isPlaying ? (
                      <>
                        <Pause className="w-4 h-4 fill-current" />
                        <span>Jeda</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4 fill-current ml-0.5" />
                        <span>Putar Musik</span>
                      </>
                    )}
                  </button>

                  <button
                    id="music-loop-btn"
                    onClick={toggleLoop}
                    className={`p-2 rounded-xl border text-xs transition flex items-center gap-1.5 ${
                      isLooping
                        ? 'bg-cyan-950/60 border-cyan-600 text-cyan-300'
                        : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
                    }`}
                    title={isLooping ? 'Loop aktif (Lagu berulang)' : 'Loop mati'}
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span className="text-[10px] hidden sm:inline">Loop</span>
                  </button>
                </div>

                {/* Volume & Mute control */}
                <div className="flex items-center gap-2">
                  <button
                    id="music-mute-btn"
                    onClick={toggleMute}
                    className="p-1.5 text-slate-400 hover:text-white transition"
                    title={isMuted ? 'Nyalakan Suara' : 'Bisukan Suara'}
                  >
                    {isMuted || volume === 0 ? (
                      <VolumeX className="w-4 h-4 text-rose-400" />
                    ) : (
                      <Volume2 className="w-4 h-4 text-slate-300" />
                    )}
                  </button>
                  <input
                    id="music-volume-slider"
                    type="range"
                    min="0"
                    max="1"
                    step="0.01"
                    value={isMuted ? 0 : volume}
                    onChange={handleVolumeChange}
                    className="w-16 sm:w-24 h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                    title={`Volume: ${Math.round((isMuted ? 0 : volume) * 100)}%`}
                  />
                </div>
              </div>
            </>
          )}

          {/* Compact Bar for Collapsed State */}
          {isCollapsed && (
            <div className="mt-2 flex items-center justify-between gap-3">
              <button
                onClick={togglePlay}
                className="px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center gap-1.5"
              >
                {isPlaying ? <Pause className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5 fill-current" />}
                <span>{isPlaying ? 'Jeda' : 'Putar'}</span>
              </button>

              {/* Mini progress bar */}
              <div
                onClick={handleSeek}
                className="flex-1 h-2 bg-slate-800 rounded-full cursor-pointer overflow-hidden"
              >
                <div
                  className="h-full bg-cyan-400 transition-all duration-150"
                  style={{ width: `${progressPercent}%` }}
                ></div>
              </div>

              <span className="text-[10px] font-mono text-slate-400 shrink-0">
                {formatTime(currentTime)} / {formatTime(duration)}
              </span>
            </div>
          )}
        </div>
      </div>
    </>
  );
};
