import React, { useState, useEffect } from 'react';
import { Terminal, Shield, UserCheck, Menu, X, Clock, Calendar, Users, BookOpen, Bell } from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';

interface NavbarProps {
  onOpenAdmin: () => void;
  activeSection?: string;
  setActiveSection?: (section: string) => void;
  onNavigate?: (sectionId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenAdmin,
  activeSection: propActiveSection,
  setActiveSection: propSetActiveSection,
  onNavigate,
}) => {
  const { user, isAdmin, logout } = useAuth();
  const [localActiveSection, setLocalActiveSection] = useState('beranda');
  const activeSection = propActiveSection ?? localActiveSection;
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [currentTime, setCurrentTime] = useState('');

  // Live WIB Clock
  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      // Calculate WIB (UTC+7)
      const utc = now.getTime() + now.getTimezoneOffset() * 60000;
      const wibDate = new Date(utc + 7 * 3600000);
      
      const hours = String(wibDate.getHours()).padStart(2, '0');
      const minutes = String(wibDate.getMinutes()).padStart(2, '0');
      const seconds = String(wibDate.getSeconds()).padStart(2, '0');
      setCurrentTime(`${hours}:${minutes}:${seconds} WIB`);
    };

    updateClock();
    const interval = setInterval(updateClock, 1000);
    return () => clearInterval(interval);
  }, []);

  const navItems = [
    { id: 'beranda', label: 'Beranda' },
    { id: 'besok', label: 'Besok Kuliah Apa?', highlight: true },
    { id: 'jadwal', label: 'Jadwal & Kalender' },
    { id: 'struktur', label: 'Struktur (35 Mhs)' },
    { id: 'akademik', label: 'Mata Kuliah & Dosen' },
    { id: 'pengumuman', label: 'Pengumuman' },
  ];

  const handleNavClick = (id: string) => {
    if (propSetActiveSection) {
      propSetActiveSection(id);
    } else {
      setLocalActiveSection(id);
    }
    setMobileMenuOpen(false);
    if (onNavigate) {
      onNavigate(id);
    } else {
      const element = document.getElementById(id);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#070b14]/90 backdrop-blur-md border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Identity */}
          <div 
            className="flex items-center space-x-3 cursor-pointer group"
            onClick={() => handleNavClick('beranda')}
          >
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-blue-500/20 group-hover:shadow-cyan-500/40 transition-all">
              <Terminal className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-extrabold text-sm tracking-wider text-white font-mono">UNP KEDIRI</span>
                <span className="px-1.5 py-0.5 text-[10px] font-bold bg-blue-950 text-cyan-400 border border-cyan-500/40 rounded">1C</span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium tracking-tight">Teknik Informatika • 35 Mahasiswa</p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center space-x-1">
            {navItems.map((item) => {
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav-link-${item.id}`}
                  onClick={() => handleNavClick(item.id)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all ${
                    isActive
                      ? 'bg-blue-600/20 text-cyan-400 border border-cyan-500/30 font-semibold'
                      : item.highlight
                      ? 'text-cyan-300 hover:text-white hover:bg-cyan-950/40 border border-cyan-500/20'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Right Area: Live WIB Clock & Admin Controls */}
          <div className="hidden md:flex items-center space-x-3">
            {/* Live Clock */}
            <div className="flex items-center space-x-1.5 px-2.5 py-1 rounded bg-slate-900/80 border border-slate-800 text-[11px] text-slate-300 font-mono">
              <Clock className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              <span>{currentTime}</span>
            </div>

            {/* Admin Action */}
            {isAdmin ? (
              <div className="flex items-center space-x-2">
                <button
                  id="admin-dashboard-btn"
                  onClick={onOpenAdmin}
                  className="flex items-center space-x-1.5 px-3 py-1.5 rounded-md bg-emerald-950/60 border border-emerald-500/50 text-emerald-400 hover:bg-emerald-900/50 text-xs font-semibold transition"
                >
                  <UserCheck className="w-3.5 h-3.5" />
                  <span>Admin Panel</span>
                </button>
                <button
                  id="admin-logout-btn"
                  onClick={logout}
                  className="px-2.5 py-1.5 rounded-md bg-slate-900 border border-slate-700 text-slate-400 hover:text-rose-400 text-xs transition"
                >
                  Keluar
                </button>
              </div>
            ) : (
              <button
                id="admin-login-modal-btn"
                onClick={onOpenAdmin}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-md bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-slate-600 text-slate-300 hover:text-white text-xs font-medium transition"
              >
                <Shield className="w-3.5 h-3.5 text-cyan-400" />
                <span>Login Admin</span>
              </button>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center space-x-2">
            <button
              id="mobile-menu-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-md bg-slate-900 border border-slate-800 text-slate-300 hover:text-white"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-800 bg-[#070b14]/98 px-4 pt-3 pb-5 space-y-2">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800/80 mb-2">
            <span className="text-[11px] text-slate-400 font-mono">Waktu Server (WIB):</span>
            <span className="text-xs text-cyan-400 font-mono font-semibold">{currentTime}</span>
          </div>
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className="block w-full text-left px-3 py-2 text-sm font-medium rounded-md text-slate-200 hover:bg-slate-800 hover:text-cyan-400 transition"
            >
              {item.label}
            </button>
          ))}
          <div className="pt-3 border-t border-slate-800">
            {isAdmin ? (
              <div className="space-y-2">
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenAdmin();
                  }}
                  className="w-full flex items-center justify-center space-x-2 px-3 py-2 rounded-md bg-emerald-950 border border-emerald-500/60 text-emerald-400 text-xs font-bold"
                >
                  <UserCheck className="w-4 h-4" />
                  <span>Buka Dashboard Admin</span>
                </button>
                <button
                  onClick={logout}
                  className="w-full py-2 text-center text-xs text-rose-400 bg-slate-900 rounded-md border border-slate-800"
                >
                  Keluar Admin
                </button>
              </div>
            ) : (
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenAdmin();
                }}
                className="w-full flex items-center justify-center space-x-2 px-3 py-2 rounded-md bg-slate-900 border border-slate-700 text-slate-200 text-xs font-semibold"
              >
                <Shield className="w-4 h-4 text-cyan-400" />
                <span>Login Administrator</span>
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
