import {
  AdminStats,
  Announcement,
  AuditLog,
  CalendarDay,
  CalendarResponse,
  Course,
  Lecturer,
  ScheduleItem,
  Student,
  TomorrowScheduleResponse,
  User,
} from '../types.ts';

const STORAGE_PREFIX = 'unp_portal_';

export const DIRECT_ACCOUNTS = [
  {
    username: 'mono170408',
    email: 'mono170408@gmail.com',
    password: 'ziqin17042008',
    name: 'Administrator Mono',
    role: 'ADMIN',
  },
  {
    username: 'admin',
    email: 'admin@unpkediri.ac.id',
    password: 'AdminUNP#2026!',
    name: 'Admin Utama UNP Kediri',
    role: 'ADMIN',
  },
];

const INITIAL_INFO = {
  university: 'Universitas Nusantara PGRI Kediri',
  faculty: 'Fakultas Teknik & Ilmu Komputer',
  studyProgram: 'Teknik Informatika',
  classCode: 'TI 1C',
  totalStudents: 35,
  tagline: 'Portal Informasi & Jadwal Kuliah Angkatan 2024 Kelas TI 1C',
};

const INITIAL_COURSES: Course[] = [
  {
    id: 'c-1',
    name: '[DEMO] Matematika Diskrit',
    code: 'TI-101',
    sks: 3,
    description: 'Logika matematika, himpunan, relasi fungsi, graf, dan struktur aljabar untuk komputasi.',
    lecturerNames: 'Dosen Demo 01, M.Kom.',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'c-2',
    name: '[DEMO] Algoritma & Pemrograman',
    code: 'TI-102',
    sks: 3,
    description: 'Konsep dasar algoritma, flowchart, pseudocode, dan dasar pemrograman berstruktur.',
    lecturerNames: 'Dosen Demo 02, M.Cs.',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'c-3',
    name: '[DEMO] Struktur Data',
    code: 'TI-103',
    sks: 3,
    description: 'Array, stack, queue, linked list, tree, hash table, dan efisiensi algoritma.',
    lecturerNames: 'Dosen Demo 02, M.Cs.',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'c-4',
    name: '[DEMO] Basis Data I',
    code: 'TI-104',
    sks: 3,
    description: 'Model relasional data, normalisasi, ERD, dan query SQL dasar hingga menengah.',
    lecturerNames: 'Dosen Demo 03, M.T.',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'c-5',
    name: '[DEMO] Sistem Operasi',
    code: 'TI-105',
    sks: 3,
    description: 'Manajemen proses, memori, thread, concurrency, file system, dan arsitektur OS.',
    lecturerNames: 'Dosen Demo 04, M.Kom.',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'c-6',
    name: '[DEMO] Pengantar Teknologi Informasi',
    code: 'TI-106',
    sks: 2,
    description: 'Pengenalan infrastruktur TI modern, cloud computing, network, dan etika profesi.',
    lecturerNames: 'Dosen Demo 05, M.Pd.',
    createdAt: new Date().toISOString(),
  },
];

const INITIAL_LECTURERS: Lecturer[] = [
  {
    id: 'l-1',
    name: 'Dosen Demo 01, M.Kom.',
    email: 'dosendemo01@unpkediri.ac.id',
    room: 'Ruang Dosen Gedung D',
    courseNames: '[DEMO] Matematika Diskrit',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'l-2',
    name: 'Dosen Demo 02, M.Cs.',
    email: 'dosendemo02@unpkediri.ac.id',
    room: 'Ruang Dosen Gedung D',
    courseNames: '[DEMO] Algoritma & Pemrograman, [DEMO] Struktur Data',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'l-3',
    name: 'Dosen Demo 03, M.T.',
    email: 'dosendemo03@unpkediri.ac.id',
    room: 'Ruang Dosen Gedung B Lt. 2',
    courseNames: '[DEMO] Basis Data I',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'l-4',
    name: 'Dosen Demo 04, M.Kom.',
    email: 'dosendemo04@unpkediri.ac.id',
    room: 'Lab Komputer Gd. D',
    courseNames: '[DEMO] Sistem Operasi',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'l-5',
    name: 'Dosen Demo 05, M.Pd.',
    email: 'dosendemo05@unpkediri.ac.id',
    room: 'Gedung Rektorat Lt. 2',
    courseNames: '[DEMO] Pengantar Teknologi Informasi',
    createdAt: new Date().toISOString(),
  },
];

const INITIAL_SCHEDULES: ScheduleItem[] = [
  {
    id: 'sch-1',
    courseId: 'c-1',
    lecturerId: 'l-1',
    dayOfWeek: 1, // Senin
    startTime: '08:00',
    endTime: '10:30',
    room: 'Ruang D.204',
    recurrenceType: 'WEEKLY',
    courseName: '[DEMO] Matematika Diskrit',
    courseCode: 'TI-101',
    courseSks: 3,
    lecturerName: 'Dosen Demo 01, M.Kom.',
    lecturerRoom: 'Ruang Dosen Gedung D',
  },
  {
    id: 'sch-2',
    courseId: 'c-6',
    lecturerId: 'l-5',
    dayOfWeek: 1, // Senin
    startTime: '13:00',
    endTime: '14:40',
    room: 'Ruang D.205',
    recurrenceType: 'WEEKLY',
    courseName: '[DEMO] Pengantar Teknologi Informasi',
    courseCode: 'TI-106',
    courseSks: 2,
    lecturerName: 'Dosen Demo 05, M.Pd.',
    lecturerRoom: 'Gedung Rektorat Lt. 2',
  },
  {
    id: 'sch-3',
    courseId: 'c-2',
    lecturerId: 'l-2',
    dayOfWeek: 2, // Selasa
    startTime: '08:00',
    endTime: '10:30',
    room: 'Lab Komputer 1',
    recurrenceType: 'WEEKLY',
    courseName: '[DEMO] Algoritma & Pemrograman',
    courseCode: 'TI-102',
    courseSks: 3,
    lecturerName: 'Dosen Demo 02, M.Cs.',
    lecturerRoom: 'Ruang Dosen Gedung D',
  },
  {
    id: 'sch-4',
    courseId: 'c-4',
    lecturerId: 'l-3',
    dayOfWeek: 3, // Rabu
    startTime: '09:00',
    endTime: '11:30',
    room: 'Lab Komputer 2',
    recurrenceType: 'WEEKLY',
    courseName: '[DEMO] Basis Data I',
    courseCode: 'TI-104',
    courseSks: 3,
    lecturerName: 'Dosen Demo 03, M.T.',
    lecturerRoom: 'Ruang Dosen Gedung B Lt. 2',
  },
  {
    id: 'sch-5',
    courseId: 'c-3',
    lecturerId: 'l-2',
    dayOfWeek: 4, // Kamis
    startTime: '08:00',
    endTime: '10:30',
    room: 'Ruang D.301',
    recurrenceType: 'WEEKLY',
    courseName: '[DEMO] Struktur Data',
    courseCode: 'TI-103',
    courseSks: 3,
    lecturerName: 'Dosen Demo 02, M.Cs.',
    lecturerRoom: 'Ruang Dosen Gedung D',
  },
  {
    id: 'sch-6',
    courseId: 'c-5',
    lecturerId: 'l-4',
    dayOfWeek: 4, // Kamis
    startTime: '13:00',
    endTime: '15:30',
    room: 'Lab Komputer 3',
    recurrenceType: 'WEEKLY',
    courseName: '[DEMO] Sistem Operasi',
    courseCode: 'TI-105',
    courseSks: 3,
    lecturerName: 'Dosen Demo 04, M.Kom.',
    lecturerRoom: 'Lab Komputer Gd. D',
  },
  {
    id: 'sch-7',
    courseId: 'c-1',
    lecturerId: 'l-1',
    dayOfWeek: 5, // Jumat
    startTime: '08:30',
    endTime: '11:00',
    room: 'Ruang D.204',
    recurrenceType: 'WEEKLY',
    courseName: '[DEMO] Diskusi Proyek & Praktikum Mandiri',
    courseCode: 'TI-101',
    courseSks: 2,
    lecturerName: 'Dosen Demo 01, M.Kom.',
    lecturerRoom: 'Ruang Dosen Gedung D',
  },
];

const INITIAL_STUDENTS: Student[] = Array.from({ length: 35 }, (_, idx) => {
  const i = idx + 1;
  const padNum = String(i).padStart(2, '0');
  const npmPad = String(i).padStart(4, '0');
  const npm = `24.1.03.02.${npmPad}`;
  let position = 'Anggota';
  let division = 'Anggota Kelas';

  if (i === 1) {
    position = 'Ketua Kelas';
    division = 'Pengurus Harian';
  } else if (i === 2) {
    position = 'Wakil Ketua';
    division = 'Pengurus Harian';
  } else if (i === 3) {
    position = 'Sekretaris';
    division = 'Pengurus Harian';
  } else if (i === 4) {
    position = 'Bendahara';
    division = 'Pengurus Harian';
  } else if (i >= 5 && i <= 8) {
    position = i === 5 ? 'Koordinator Divisi' : 'Anggota Divisi';
    division = 'Akademik & Riset';
  } else if (i >= 9 && i <= 12) {
    position = i === 9 ? 'Koordinator Divisi' : 'Anggota Divisi';
    division = 'Humas & Publikasi';
  } else if (i >= 13 && i <= 16) {
    position = i === 13 ? 'Koordinator Divisi' : 'Anggota Divisi';
    division = 'Kreatif & Logistik';
  }

  return {
    id: `mhs-${i}`,
    name: `Mahasiswa ${padNum}`,
    npm,
    position,
    division,
    orderIndex: i,
  };
});

const INITIAL_ANNOUNCEMENTS: Announcement[] = [
  {
    id: 'ann-1',
    title: '[DEMO] Selamat Datang di Portal Kelas TI 1C Universitas Nusantara PGRI',
    content:
      'Portal ini dibangun sebagai media informasi internal untuk seluruh mahasiswa TI 1C. Silakan cek jadwal kuliah rutin, daftar mata kuliah, dosen pengampu, dan struktur kepengurusan kelas di menu yang tersedia.',
    category: 'Umum',
    published: 1,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'ann-2',
    title: '[DEMO] Sosialisasi Praktikum Algoritma & Pemrograman di Lab Komputer 1',
    content:
      'Diberitahukan kepada seluruh mahasiswa TI 1C bahwa praktikum pemrograman setiap Selasa pukul 08:00 wajib membawa laptop dengan software IDE yang telah ditentukan.',
    category: 'Akademik',
    published: 1,
    createdAt: new Date(Date.now() - 3600000).toISOString(),
    updatedAt: new Date(Date.now() - 3600000).toISOString(),
  },
  {
    id: 'ann-3',
    title: '[DEMO] Pengumpulan Form Biodata dan Verifikasi NPM Mahasiswa 1C',
    content:
      'Mohon bagi mahasiswa yang belum memverifikasi data NPM dan kontak harap melapor ke Sekretaris kelas untuk sinkronisasi data presensi.',
    category: 'Tugas',
    published: 1,
    createdAt: new Date(Date.now() - 7200000).toISOString(),
    updatedAt: new Date(Date.now() - 7200000).toISOString(),
  },
];

const INITIAL_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'log-1',
    userId: 'admin-1',
    userEmail: 'mono170408@gmail.com',
    action: 'SYSTEM INITIALIZE',
    details: 'Portal TI 1C UNP Kediri siap digunakan (Mode Netlify / Standalone)',
    createdAt: new Date().toISOString(),
  },
];

function getStored<T>(key: string, defaultValue: T): T {
  try {
    const raw = localStorage.getItem(STORAGE_PREFIX + key);
    if (!raw) return defaultValue;
    return JSON.parse(raw) as T;
  } catch {
    return defaultValue;
  }
}

function setStored<T>(key: string, value: T): void {
  try {
    localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(value));
  } catch (err) {
    console.warn('LocalStorage quota or access error:', err);
  }
}

export const localStore = {
  getInfo() {
    return getStored(STORAGE_PREFIX + 'info', INITIAL_INFO);
  },

  getCourses(): Course[] {
    return getStored('courses', INITIAL_COURSES);
  },

  setCourses(courses: Course[]) {
    setStored('courses', courses);
  },

  getLecturers(): Lecturer[] {
    return getStored('lecturers', INITIAL_LECTURERS);
  },

  setLecturers(lecturers: Lecturer[]) {
    setStored('lecturers', lecturers);
  },

  getSchedules(): ScheduleItem[] {
    const schedules = getStored<ScheduleItem[]>('schedules', INITIAL_SCHEDULES);
    const courses = this.getCourses();
    const lecturers = this.getLecturers();

    // Enrich with names
    return schedules.map((s) => {
      const c = courses.find((course) => course.id === s.courseId);
      const l = lecturers.find((lec) => lec.id === s.lecturerId);
      return {
        ...s,
        courseName: c?.name || s.courseName || 'Mata Kuliah',
        courseCode: c?.code || s.courseCode || '-',
        courseSks: c?.sks || s.courseSks || 2,
        lecturerName: l?.name || s.lecturerName || 'Dosen Pengampu',
        lecturerRoom: l?.room || s.lecturerRoom || '-',
      };
    });
  },

  setSchedules(schedules: ScheduleItem[]) {
    setStored('schedules', schedules);
  },

  getStudents(): Student[] {
    return getStored('students', INITIAL_STUDENTS);
  },

  setStudents(students: Student[]) {
    setStored('students', students);
  },

  getAnnouncements(): Announcement[] {
    return getStored('announcements', INITIAL_ANNOUNCEMENTS);
  },

  setAnnouncements(announcements: Announcement[]) {
    setStored('announcements', announcements);
  },

  getAuditLogs(): AuditLog[] {
    return getStored('audit_logs', INITIAL_AUDIT_LOGS);
  },

  addAuditLog(userEmail: string, action: string, details?: string) {
    const logs = this.getAuditLogs();
    const newLog: AuditLog = {
      id: 'log-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      userId: 'usr-local',
      userEmail,
      action,
      details,
      createdAt: new Date().toISOString(),
    };
    const updated = [newLog, ...logs].slice(0, 50);
    setStored('audit_logs', updated);
  },

  getTomorrowSchedule(): TomorrowScheduleResponse {
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);

    const dayOfWeek = tomorrow.getDay() === 0 ? 7 : tomorrow.getDay();
    const isoDate = tomorrow.toISOString().split('T')[0];

    const dayNames = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    const monthNames = [
      'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
      'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember',
    ];

    const dayName = dayNames[tomorrow.getDay()];
    const dateFormatted = `${tomorrow.getDate()} ${monthNames[tomorrow.getMonth()]} ${tomorrow.getFullYear()}`;

    const allSchedules = this.getSchedules();
    const tomorrowClasses = allSchedules
      .filter((s) => {
        if (s.recurrenceType === 'SPECIFIC_DATE') {
          return s.specificDate === isoDate;
        }
        return s.dayOfWeek === dayOfWeek;
      })
      .sort((a, b) => a.startTime.localeCompare(b.startTime));

    return {
      dayName,
      dateFormatted,
      isoDate,
      hasClasses: tomorrowClasses.length > 0,
      classes: tomorrowClasses,
    };
  },

  getCalendar(year?: number, month?: number): CalendarResponse {
    const now = new Date();
    const y = year || now.getFullYear();
    const m = month || now.getMonth() + 1;

    const daysInMonth = new Date(y, m, 0).getDate();
    const schedules = this.getSchedules();

    const days: CalendarDay[] = [];
    for (let d = 1; d <= daysInMonth; d++) {
      const dateObj = new Date(y, m - 1, d);
      const dayOfWeek = dateObj.getDay() === 0 ? 7 : dateObj.getDay();
      const isoDate = `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;

      const daySchedules = schedules
        .filter((s) => {
          if (s.recurrenceType === 'SPECIFIC_DATE') {
            return s.specificDate === isoDate;
          }
          return s.dayOfWeek === dayOfWeek;
        })
        .sort((a, b) => a.startTime.localeCompare(b.startTime));

      days.push({
        date: isoDate,
        dayNumber: d,
        dayOfWeek,
        hasClasses: daySchedules.length > 0,
        schedules: daySchedules,
      });
    }

    return {
      year: y,
      month: m,
      days,
    };
  },

  getAdminStats(): AdminStats {
    return {
      coursesCount: this.getCourses().length,
      lecturersCount: this.getLecturers().length,
      schedulesCount: this.getSchedules().length,
      studentsCount: this.getStudents().length,
      announcementsCount: this.getAnnouncements().length,
    };
  },

  authenticateDirect(identifier: string, pass: string): { user: User; token: string } | null {
    const cleanId = identifier.trim().toLowerCase();
    const matched = DIRECT_ACCOUNTS.find((acc) => {
      const matchName =
        acc.username.toLowerCase() === cleanId ||
        acc.email.toLowerCase() === cleanId ||
        cleanId === 'admin' ||
        cleanId === 'mono170408';
      return matchName && acc.password === pass;
    });

    if (!matched) return null;

    const token = 'local_jwt_' + Math.random().toString(36).substring(2) + Date.now().toString(36);
    const user: User = {
      id: 'usr-' + matched.username,
      email: matched.email,
      role: 'ADMIN',
    };

    setStored('session_user', user);
    setStored('session_token', token);
    this.addAuditLog(matched.email, 'ADMIN LOGIN', 'Login admin langsung (Netlify / Mode Standalone)');

    return { user, token };
  },

  getCurrentUser(): User | null {
    return getStored<User | null>('session_user', null);
  },

  clearSession() {
    try {
      localStorage.removeItem(STORAGE_PREFIX + 'session_user');
      localStorage.removeItem(STORAGE_PREFIX + 'session_token');
    } catch {
      // ignore
    }
  },
};
