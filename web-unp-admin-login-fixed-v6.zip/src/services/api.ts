import {
  AdminStats,
  Announcement,
  AuditLog,
  CalendarResponse,
  Course,
  Lecturer,
  ScheduleItem,
  Student,
  TomorrowScheduleResponse,
  User,
} from '../types.ts';
import { localStore } from './localData.ts';

const API_BASE = '/api';
const TOKEN_STORAGE_KEY = 'unp_auth_token';

export function getAuthToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_STORAGE_KEY);
  } catch {
    return null;
  }
}

export function setAuthToken(token: string | null): void {
  try {
    if (token) {
      localStorage.setItem(TOKEN_STORAGE_KEY, token);
    } else {
      localStorage.removeItem(TOKEN_STORAGE_KEY);
    }
  } catch {
    // Ignore localStorage write errors
  }
}

async function fetchJson<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getAuthToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers,
    credentials: 'include',
  });

  const contentType = res.headers.get('content-type') || '';
  if (!contentType.includes('application/json')) {
    throw new Error(`Endpoint ${endpoint} tidak mengembalikan JSON (status ${res.status})`);
  }

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    if (res.status === 401) {
      setAuthToken(null);
    }
    throw new Error(data.error || `Permintaan gagal dengan status ${res.status}`);
  }

  return data as T;
}

export const api = {
  // ==========================================
  // PUBLIC ENDPOINTS
  // ==========================================
  getInfo: async () => {
    try {
      return await fetchJson<{
        university: string;
        faculty: string;
        studyProgram: string;
        classCode: string;
        totalStudents: number;
        tagline: string;
      }>('/info');
    } catch {
      return localStore.getInfo();
    }
  },

  getTomorrowSchedule: async (): Promise<TomorrowScheduleResponse> => {
    try {
      return await fetchJson<TomorrowScheduleResponse>('/schedule/tomorrow');
    } catch {
      return localStore.getTomorrowSchedule();
    }
  },

  getCalendar: async (year?: number, month?: number): Promise<CalendarResponse> => {
    try {
      const params = new URLSearchParams();
      if (year) params.append('year', year.toString());
      if (month) params.append('month', month.toString());
      const queryStr = params.toString() ? `?${params.toString()}` : '';
      return await fetchJson<CalendarResponse>(`/schedule/calendar${queryStr}`);
    } catch {
      return localStore.getCalendar(year, month);
    }
  },

  getSchedules: async (): Promise<ScheduleItem[]> => {
    try {
      return await fetchJson<ScheduleItem[]>('/schedules');
    } catch {
      return localStore.getSchedules();
    }
  },

  getCourses: async (): Promise<Course[]> => {
    try {
      return await fetchJson<Course[]>('/courses');
    } catch {
      return localStore.getCourses();
    }
  },

  getLecturers: async (): Promise<Lecturer[]> => {
    try {
      return await fetchJson<Lecturer[]>('/lecturers');
    } catch {
      return localStore.getLecturers();
    }
  },

  getStudents: async (): Promise<Student[]> => {
    try {
      return await fetchJson<Student[]>('/students');
    } catch {
      return localStore.getStudents();
    }
  },

  getAnnouncements: async (): Promise<Announcement[]> => {
    try {
      return await fetchJson<Announcement[]>('/announcements');
    } catch {
      return localStore.getAnnouncements().filter((a) => a.published === 1);
    }
  },

  // ==========================================
  // AUTHENTICATION
  // ==========================================
  login: async (credentials: { email: string; password: string }) => {
    const inputIdentifier = credentials.email.trim();
    const inputPassword = credentials.password;

    // IMPORTANT: Admin authentication must always be verified by the server.
    // Do not fall back to localStorage / Direct Admin Mode because those local
    // tokens are not valid for protected server endpoints.
    const res = await fetchJson<{ message: string; user: User; token: string }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email: inputIdentifier, password: inputPassword }),
    });

    if (!res.token) {
      throw new Error('Server login tidak mengembalikan session token.');
    }

    setAuthToken(res.token);
    try {
      localStore.clearSession();
    } catch {
      // Ignore local storage cleanup errors.
    }

    // Verify the token immediately. This prevents the UI from saying
    // "login berhasil" when the following protected request would fail.
    const verified = await fetchJson<{ user: User }>('/auth/me');
    return { ...res, user: verified.user };
  },

  logout: async () => {
    try {
      await fetchJson<{ message: string }>('/auth/logout', { method: 'POST' });
    } catch {
      // Ignore network errors on logout
    } finally {
      setAuthToken(null);
      localStore.clearSession();
    }
    return { message: 'Berhasil keluar' };
  },

  getMe: async (): Promise<{ user: User }> => {
    // Authentication state comes only from the server. Never reconstruct an
    // authenticated user from localStorage.
    return await fetchJson<{ user: User }>('/auth/me');
  },

  // ==========================================
  // ADMIN PROTECTED ENDPOINTS
  // ==========================================
  getAdminStats: async (): Promise<AdminStats> => {
    try {
      return await fetchJson<AdminStats>('/admin/stats');
    } catch (err) {
      throw err;
    }
  },

  getAuditLogs: async (): Promise<AuditLog[]> => {
    try {
      return await fetchJson<AuditLog[]>('/admin/audit-logs');
    } catch (err) {
      throw err;
    }
  },

  getAdminAnnouncements: async (): Promise<Announcement[]> => {
    try {
      return await fetchJson<Announcement[]>('/admin/announcements');
    } catch (err) {
      throw err;
    }
  },

  // --- Courses ---
  createCourse: async (data: { name: string; code: string; sks: number; description?: string }) => {
    try {
      return await fetchJson<{ id: string; message: string }>('/admin/courses', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    } catch (err) {
      throw err;
    }
  },

  updateCourse: async (
    id: string,
    data: { name: string; code: string; sks: number; description?: string }
  ) => {
    try {
      return await fetchJson<{ message: string }>(`/admin/courses/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
      });
    } catch (err) {
      throw err;
    }
  },

  deleteCourse: async (id: string) => {
    try {
      return await fetchJson<{ message: string }>(`/admin/courses/${id}`, {
        method: 'DELETE',
      });
    } catch (err) {
      throw err;
    }
  },

  // --- Lecturers ---
  createLecturer: async (data: { name: string; email?: string; room?: string }) => {
    try {
      return await fetchJson<{ id: string; message: string }>('/admin/lecturers', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    } catch (err) {
      throw err;
    }
  },

  updateLecturer: async (id: string, data: { name: string; email?: string; room?: string }) => {
    try {
      return await fetchJson<{ message: string }>(`/admin/lecturers/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
      });
    } catch (err) {
      throw err;
    }
  },

  deleteLecturer: async (id: string) => {
    try {
      return await fetchJson<{ message: string }>(`/admin/lecturers/${id}`, {
        method: 'DELETE',
      });
    } catch (err) {
      throw err;
    }
  },

  // --- Schedules ---
  createSchedule: async (data: {
    courseId: string;
    lecturerId: string;
    dayOfWeek: number;
    startTime: string;
    endTime: string;
    room: string;
    recurrenceType: 'WEEKLY' | 'SPECIFIC_DATE';
    specificDate?: string | null;
    forceConflict?: boolean;
  }) => {
    try {
      return await fetchJson<{ id: string; message: string }>('/admin/schedules', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    } catch (err) {
      throw err;
    }
  },

  updateSchedule: async (
    id: string,
    data: {
      courseId: string;
      lecturerId: string;
      dayOfWeek: number;
      startTime: string;
      endTime: string;
      room: string;
      recurrenceType: 'WEEKLY' | 'SPECIFIC_DATE';
      specificDate?: string | null;
      forceConflict?: boolean;
    }
  ) => {
    try {
      return await fetchJson<{ message: string }>(`/admin/schedules/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
      });
    } catch (err) {
      throw err;
    }
  },

  deleteSchedule: async (id: string) => {
    try {
      return await fetchJson<{ message: string }>(`/admin/schedules/${id}`, {
        method: 'DELETE',
      });
    } catch (err) {
      throw err;
    }
  },

  // --- Announcements ---
  createAnnouncement: async (data: {
    title: string;
    content: string;
    category: string;
    published: number;
  }) => {
    try {
      return await fetchJson<{ id: string; message: string }>('/admin/announcements', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    } catch (err) {
      throw err;
    }
  },

  updateAnnouncement: async (
    id: string,
    data: { title: string; content: string; category: string; published: number }
  ) => {
    try {
      return await fetchJson<{ message: string }>(`/admin/announcements/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
      });
    } catch (err) {
      throw err;
    }
  },

  deleteAnnouncement: async (id: string) => {
    try {
      return await fetchJson<{ message: string }>(`/admin/announcements/${id}`, {
        method: 'DELETE',
      });
    } catch (err) {
      throw err;
    }
  },

  // --- Students ---
  updateStudent: async (
    id: string,
    data: { name: string; npm: string; position: string; division: string }
  ) => {
    try {
      return await fetchJson<{ message: string }>(`/admin/students/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
      });
    } catch (err) {
      throw err;
    }
  },
};
